import QtQuick 2.15

Rectangle {
    id: root

    width: 1920
    height: 1080
    color: "#000000"

    property color accent: "#8a97bf"
    property color accentLight: "#c7cde0"
    property color accentMid: "#59617d"
    property color accentDark: "#252a37"
    property color fieldBackground: "#08090c"

    readonly property int sessionIndex: sessionModel.count === 0 ? -1
        : (sessionModel.lastIndex >= 0 && sessionModel.lastIndex < sessionModel.count
           ? sessionModel.lastIndex : 0)
    property string statusText: ""
    property bool loginBusy: false

    function isEnterEquivalent(event) {
        if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter)
            return true

        if (!(event.modifiers & Qt.ControlModifier) ||
            (event.modifiers & (Qt.ShiftModifier | Qt.AltModifier | Qt.MetaModifier)))
            return false

        return event.key === Qt.Key_1 ||
               event.key === Qt.Key_2 ||
               event.key === Qt.Key_3 ||
               event.key === Qt.Key_4 ||
               event.key === Qt.Key_5 ||
               event.key === Qt.Key_6 ||
               event.key === Qt.Key_7 ||
               event.key === Qt.Key_8 ||
               event.key === Qt.Key_9
    }

    function attemptLogin() {
        if (loginBusy || username.text.length === 0)
            return

        if (sessionIndex < 0) {
            statusText = "no desktop session available"
            return
        }

        statusText = ""
        loginBusy = true
        sddm.login(username.text, password.text, sessionIndex)
    }

    Connections {
        target: sddm

        function onLoginFailed() {
            root.loginBusy = false
            root.statusText = "Authentication failure"
            password.text = ""
            password.forceActiveFocus()
        }

        function onLoginSucceeded() {
            root.loginBusy = true
            root.statusText = ""
            password.text = ""
        }
    }

    Column {
        id: loginPanel

        width: Math.max(0, Math.min(300, root.width - 64))
        spacing: 11
        anchors.centerIn: parent

        Text {
            text: "user"
            color: root.accentMid
            font.pixelSize: 10
            font.letterSpacing: 1.2
        }

        Rectangle {
            width: parent.width
            height: 42
            radius: 3
            color: root.fieldBackground
            border.width: 1
            border.color: root.accentDark

            TextInput {
                id: username
                enabled: !root.loginBusy

                anchors.fill: parent
                anchors.leftMargin: 13
                anchors.rightMargin: 13
                verticalAlignment: TextInput.AlignVCenter

                text: ""
                color: root.accentLight
                selectionColor: root.accent
                selectedTextColor: "#000000"
                font.pixelSize: 14
                clip: true
                focus: true

                KeyNavigation.tab: password
                KeyNavigation.backtab: password
                inputMethodHints: Qt.ImhNoAutoUppercase | Qt.ImhNoPredictiveText

                Keys.onPressed: function(event) {
                    if (root.isEnterEquivalent(event) && !username.inputMethodComposing) {
                        if (!event.isAutoRepeat)
                            password.forceActiveFocus()
                        event.accepted = true
                    }
                }
            }
        }

        Text {
            text: "password"
            color: root.accentMid
            font.pixelSize: 10
            font.letterSpacing: 1.2
        }

        Rectangle {
            width: parent.width
            height: 42
            radius: 3
            color: root.fieldBackground
            border.width: 1
            border.color: root.accentDark

            TextInput {
                id: password
                enabled: !root.loginBusy

                anchors.fill: parent
                anchors.leftMargin: 13
                anchors.rightMargin: 13
                verticalAlignment: TextInput.AlignVCenter

                color: root.accentLight
                selectionColor: root.accent
                selectedTextColor: "#000000"
                font.pixelSize: 14
                echoMode: TextInput.Password
                passwordMaskDelay: 0
                inputMethodHints: Qt.ImhHiddenText | Qt.ImhSensitiveData
                    | Qt.ImhNoAutoUppercase | Qt.ImhNoPredictiveText
                clip: true
                focus: false

                KeyNavigation.tab: username
                KeyNavigation.backtab: username

                Keys.onPressed: function(event) {
                    if (root.isEnterEquivalent(event) && !password.inputMethodComposing) {
                        if (!event.isAutoRepeat)
                            root.attemptLogin()
                        event.accepted = true
                    } else if (event.key === Qt.Key_Escape) {
                        password.text = ""
                        event.accepted = true
                    }
                }
            }
        }

        Item {
            width: parent.width
            height: keyboard.capsLock ? 14 : 0
            visible: keyboard.capsLock

            Text {
                anchors.right: parent.right
                text: "caps lock"
                color: root.accentMid
                font.pixelSize: 9
                font.letterSpacing: 0.7
            }
        }

        Item {
            width: parent.width
            height: 17

            Text {
                anchors.centerIn: parent
                width: parent.width
                horizontalAlignment: Text.AlignHCenter

                text: root.statusText
                textFormat: Text.PlainText
                color: root.accent
                font.pixelSize: 10
            }
        }
    }

    // Keeps the pointer blank within the greeter. The display-server cursor
    // configuration also covers the time before this window opens and after it closes.
    MouseArea {
        anchors.fill: parent
        z: 9999
        hoverEnabled: true
        acceptedButtons: Qt.NoButton
        cursorShape: Qt.BlankCursor
    }

    Component.onCompleted: {
        username.forceActiveFocus()
    }
}
