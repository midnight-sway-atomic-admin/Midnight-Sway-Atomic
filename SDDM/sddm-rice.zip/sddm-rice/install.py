#!/usr/bin/env python3
"""Install this theme and cursor fix for Fedora Sway Atomic's Wayland greeter."""
import argparse
import configparser
import datetime
import json
import os
from pathlib import Path
import pwd
import shlex
import shutil
import subprocess
import tempfile

SOURCE = Path(__file__).resolve().parent
SYSTEM_CONFIG = Path('/usr/lib/sddm/sddm.conf.d')
LOCAL_CONFIG = Path('/etc/sddm.conf.d')
MAIN_CONFIG = Path('/etc/sddm.conf')
BACKUPS = Path('/var/lib/sddm/rice-backups')
DROPIN = Path('/etc/sddm.conf.d/99-sddm-rice.conf')
GREETER = Path('/etc/sway/sddm-greeter.config')
THEME = Path('/var/lib/sddm/themes/sddm-rice')
CURSORS = Path('/var/lib/sddm/.icons/sddm-rice-invisible')
CURSOR_LINE = 'seat * xcursor_theme sddm-rice-invisible 24'


def parser():
    p = configparser.ConfigParser(interpolation=None, strict=False)
    p.optionxform = str
    return p


def configuration(defaults, replacement=None):
    p = parser()
    p.read_string(defaults)
    for directory in [SYSTEM_CONFIG, LOCAL_CONFIG]:
        paths = set(directory.glob('*.conf'))
        if replacement is not None and directory == DROPIN.parent:
            paths.add(DROPIN)
        for path in sorted(paths):
            text = replacement if path == DROPIN and replacement is not None else path.read_text()
            p.read_string(text, source=str(path))
    path = MAIN_CONFIG
    if path.exists():
        p.read_string(path.read_text(), source=str(path))
    return p


def value(config, section, key, fallback=''):
    result = config.get(section, key, fallback=fallback).strip()
    # The settings inspected here are simple strings, sometimes quoted by Qt.
    if len(result) >= 2 and result[0] == result[-1] == '"':
        result = result[1:-1]
    return result


def plan(defaults):
    config = configuration(defaults)
    backend = value(config, 'General', 'DisplayServer')
    if backend != 'wayland':
        raise RuntimeError('This installer requires the Wayland/Sway greeter.\n'
                           'No files changed. Configured DisplayServer: ' + repr(backend))
    command = value(config, 'Wayland', 'CompositorCommand')
    if shlex.split(command) != ['/usr/libexec/sddm-compositor-sway']:
        raise RuntimeError('Unsupported greeter compositor: ' + command + '\n'
                           'No files changed. This installer requires Fedora\'s '
                           'sddm-compositor-sway wrapper.')
    if not GREETER.is_file():
        raise RuntimeError('Missing greeter configuration: ' + str(GREETER))
    settings = {
        'Theme': {'ThemeDir': str(THEME.parent), 'Current': THEME.name,
                  'EnableAvatars': 'false', 'CursorTheme': 'sddm-rice-invisible',
                  'CursorSize': '24'}
    }
    files = {}
    old = GREETER.read_text()
    if not old.rstrip().endswith(CURSOR_LINE):
        files[GREETER] = (old.rstrip() + '\n\n# SDDM rice: invisible compositor pointer.\n'
                          + CURSOR_LINE + '\n').encode()
    for src in sorted((SOURCE / 'cursor-theme').rglob('*')):
        if src.is_file():
            files[CURSORS / src.relative_to(SOURCE / 'cursor-theme')] = src.read_bytes()

    # Preserve any unrelated settings in an existing copy of our drop-in.
    dropin = parser()
    if DROPIN.exists():
        dropin.read_string(DROPIN.read_text())
    for section, entries in settings.items():
        if not dropin.has_section(section):
            dropin.add_section(section)
        for key, setting in entries.items():
            dropin.set(section, key, setting)
    import io
    output = io.StringIO()
    dropin.write(output, space_around_delimiters=False)
    proposed = output.getvalue()
    effective = configuration(defaults, proposed)
    for section, entries in settings.items():
        for key, setting in entries.items():
            if value(effective, section, key) != setting:
                raise RuntimeError(f'{section}.{key} is overridden by a later configuration.\n'
                                   'No files changed. Check /etc/sddm.conf and any .conf files '
                                   'sorted after 99-sddm-rice.conf in /etc/sddm.conf.d.')
    files[DROPIN] = proposed.encode()
    for name in ['Main.qml', 'metadata.desktop']:
        files[THEME / name] = (SOURCE / name).read_bytes()
    return 'Wayland/Sway: use the transparent cursor theme in the greeter compositor', files


def write_file(path, data, mode=0o644, uid=0, gid=0):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.sddm-rice-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temp, mode)
        os.chown(temp, uid, gid)
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('--check', action='store_true', help='check the Sway greeter setup without installing')
    options = args.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('Run this command from an administrator account with sudo.')
    if pwd.getpwnam('sddm').pw_dir != '/var/lib/sddm':
        raise RuntimeError('This installer expects Fedora\'s SDDM home: /var/lib/sddm.')
    # --example-config prints build defaults; layer the real configuration over them.
    defaults = subprocess.run(['sddm', '--example-config'], check=True, capture_output=True,
                              text=True, timeout=15).stdout
    description, files = plan(defaults)
    print(description)
    changed = {p: b for p, b in files.items() if not p.is_file() or p.read_bytes() != b}
    for path in changed:
        if path.is_symlink() or (path.exists() and not path.is_file()):
            raise RuntimeError('Refusing to replace a symlink or non-file: ' + str(path))
    if options.check:
        print(f'Check passed; {len(changed)} files would change. Nothing installed.')
        return
    if not changed:
        print('Already installed. Reboot to use it if you have not done so since installation.')
        return
    restorecon = shutil.which('restorecon')
    if not restorecon:
        raise RuntimeError('restorecon is required to restore the Fedora SELinux labels.')
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    os.umask(0o022)
    backup = BACKUPS / stamp
    backup.mkdir(parents=True, mode=0o700)
    (backup / 'state.txt').write_text('preparing\n')
    old = {}
    for path in changed:
        if path.exists():
            stat = path.stat()
            old[path] = (path.read_bytes(), stat.st_mode & 0o777, stat.st_uid, stat.st_gid)
        else:
            old[path] = None
        if old[path] is not None:
            saved = backup / path.relative_to('/')
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, saved)
    (backup / 'new-files.txt').write_text('\n'.join(str(p) for p, data in old.items() if data is None) + '\n')
    (backup / 'metadata.json').write_text(json.dumps(
        {str(path): list(data[1:]) for path, data in old.items() if data is not None}, indent=2) + '\n')
    written = []
    try:
        # Cursor data must exist before the greeter configuration can use it.
        for path in sorted(changed, key=lambda p: p in (GREETER, DROPIN)):
            metadata = old[path][1:] if old[path] else (0o644, 0, 0)
            write_file(path, changed[path], *metadata)
            written.append(path)
        label_paths = [THEME, DROPIN, CURSORS.parent, GREETER]
        subprocess.run([restorecon, '-RF', *map(str, label_paths)], check=True)
        write_file(backup / 'state.txt', b'installed\n', 0o600)
    except Exception:
        for path in reversed(written):
            if old[path] is None:
                path.unlink(missing_ok=True)
            else:
                write_file(path, *old[path])
        subprocess.run([restorecon, '-RF', str(THEME), str(DROPIN.parent), str(GREETER.parent)],
                       check=False)
        write_file(backup / 'state.txt', b'failed\n', 0o600)
        raise
    print('Installed. Previous files are saved under: ' + str(backup))
    print('Restore the pre-install setup with: sudo python3 uninstall.py')
    print('Reboot when ready. SDDM has not been restarted.')


if __name__ == '__main__':
    try:
        main()
    except (OSError, KeyError, RuntimeError, ValueError, configparser.Error,
            subprocess.SubprocessError) as error:
        raise SystemExit(str(error))
