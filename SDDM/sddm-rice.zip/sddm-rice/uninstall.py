#!/usr/bin/env python3
"""Restore the setup saved before installing SDDM rice."""
import argparse
import datetime
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

import install as setup

STAMP = re.compile(r'\d{8}T\d{6}\.\d{6}Z')
CONTROL_FILES = {'new-files.txt', 'metadata.json', 'state.txt', 'restored-by.txt'}


def regular_path(path):
    for part in (path, *path.parents):
        if part.is_symlink():
            raise RuntimeError('Refusing a path containing a symlink: ' + str(path))
    if path.exists() and not path.is_file():
        raise RuntimeError('Expected a regular file: ' + str(path))


def allowed_target(path):
    exact = {setup.DROPIN, setup.GREETER, setup.THEME / 'Main.qml',
             setup.THEME / 'metadata.desktop', setup.CURSORS / 'index.theme'}
    if (not path.is_absolute() or '..' in path.parts or
            (path not in exact and path.parent != setup.CURSORS / 'cursors')):
        raise RuntimeError('Backup contains a path outside this installer: ' + str(path))
    regular_path(path)


def snapshot(path):
    regular_path(path)
    if not path.exists():
        return None
    stat = path.stat()
    return path.read_bytes(), stat.st_mode & 0o777, stat.st_uid, stat.st_gid


def active_backups():
    result = []
    if not setup.BACKUPS.exists():
        return result
    for directory in sorted(setup.BACKUPS.iterdir()):
        if not STAMP.fullmatch(directory.name):
            continue
        regular_path(directory / 'new-files.txt')
        regular_path(directory / 'state.txt')
        regular_path(directory / 'restored-by.txt')
        if not (directory / 'new-files.txt').is_file() or (directory / 'restored-by.txt').exists():
            continue
        state = directory / 'state.txt'
        if state.exists() and state.read_text().strip() != 'installed':
            continue
        result.append(directory)
    return result


def load_backup(directory):
    saved = {}
    for source in sorted(directory.rglob('*')):
        if source.is_symlink():
            raise RuntimeError('Backup contains a symlink: ' + str(source))
        if source.is_dir():
            continue
        regular_path(source)
        relative = source.relative_to(directory)
        if len(relative.parts) == 1 and relative.name in CONTROL_FILES:
            continue
        target = Path('/') / relative
        allowed_target(target)
        saved[target] = source
    added = set()
    for line in (directory / 'new-files.txt').read_text().splitlines():
        if line:
            target = Path(line)
            allowed_target(target)
            added.add(target)
    if saved.keys() & added:
        raise RuntimeError('Backup lists a file as both existing and newly created: ' + str(directory))
    metadata_file = directory / 'metadata.json'
    regular_path(metadata_file)
    metadata = json.loads(metadata_file.read_text()) if metadata_file.exists() else None
    if metadata is not None and (not isinstance(metadata, dict) or set(metadata) != {str(p) for p in saved}):
        raise RuntimeError('Backup metadata does not match its saved files: ' + str(directory))
    files = dict.fromkeys(added)
    for target, source in saved.items():
        if metadata is not None:
            attributes = metadata[str(target)]
            if (not isinstance(attributes, list) or len(attributes) != 3 or
                    any(type(n) is not int or n < 0 for n in attributes) or attributes[0] > 0o777):
                raise RuntimeError('Invalid backup permissions: ' + str(target))
        else:
            # Versions 1.8/1.9 saved modes, but not original ownership.
            owner = target.stat() if target.exists() else source.stat()
            attributes = [source.stat().st_mode & 0o777, owner.st_uid, owner.st_gid]
        files[target] = (source.read_bytes(), *attributes)
    if not files:
        raise RuntimeError('Empty backup: ' + str(directory))
    return files


def put(path, state):
    if state is None:
        path.unlink(missing_ok=True)
    else:
        setup.write_file(path, *state)


def relabel(command, paths):
    existing = [str(path) for path in paths if path.exists()]
    if existing:
        subprocess.run([command, '-F', *existing], check=True)


def restore(backups, check=False):
    desired = {}
    for directory in reversed(backups):
        desired.update(load_backup(directory))
    current = {path: snapshot(path) for path in desired}
    changes = {path: state for path, state in desired.items() if state != current[path]}
    print('Restore the setup saved before: ' + backups[0].name)
    print(f'{len(backups)} installation(s); {len(changes)} file(s) to restore or remove.')
    if check:
        print('Check passed. No files changed.')
        return
    restorecon = shutil.which('restorecon')
    if not restorecon:
        raise RuntimeError('restorecon is required to restore the Fedora SELinux labels.')
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    recovery = setup.BACKUPS.parent / 'rice-restore-backups' / stamp
    regular_path(recovery / 'new-files.txt')
    os.umask(0o022)
    recovery.mkdir(parents=True, mode=0o700)
    for path in changes:
        if current[path] is not None:
            setup.write_file(recovery / path.relative_to('/'), *current[path])
    (recovery / 'new-files.txt').write_text(
        '\n'.join(str(p) for p in changes if current[p] is None) + '\n')
    (recovery / 'metadata.json').write_text(json.dumps(
        {str(p): list(current[p][1:]) for p in changes if current[p] is not None}, indent=2) + '\n')
    written, marked = [], []
    try:
        # Restore saved files before removing files introduced by the installer.
        for path in sorted(changes, key=lambda p: changes[p] is None):
            put(path, changes[path])
            written.append(path)
        relabel(restorecon, changes)
        for directory in backups:
            marker = directory / 'restored-by.txt'
            setup.write_file(marker, (str(recovery) + '\n').encode(), 0o600)
            marked.append(marker)
    except Exception as error:
        for marker in marked:
            marker.unlink()
        try:
            for path in reversed(written):
                put(path, current[path])
            relabel(restorecon, written)
        except Exception as rollback_error:
            raise RuntimeError(f'Restore failed: {error}\nRollback failed: {rollback_error}\n'
                               f'Pre-restore copies are in: {recovery}') from error
        raise RuntimeError(f'Restore failed and was rolled back: {error}\n'
                           f'Pre-restore copies are in: {recovery}') from error
    print('Restored. Files from before this restore are saved under: ' + str(recovery))
    print('Reboot when ready. SDDM has not been restarted.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--list', action='store_true', help='list installation backups still available to undo')
    parser.add_argument('--check', action='store_true', help='check the restore without changing files')
    parser.add_argument('--backup', help='restore before this backup and undo all newer active installs')
    options = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('Run this command from an administrator account with sudo.')
    backups = active_backups()
    if options.list:
        print('\n'.join(str(p) for p in backups) if backups else 'No active installation backups found.')
        return
    if options.backup:
        chosen = Path(options.backup)
        if not chosen.is_absolute():
            chosen = setup.BACKUPS / chosen
        if chosen not in backups:
            raise RuntimeError('That backup is not active. List available backups with --list.')
        backups = backups[backups.index(chosen):]
    if not backups:
        print('No active installation backups found. No files changed.')
        return
    restore(backups, options.check)


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError, subprocess.SubprocessError) as error:
        raise SystemExit(str(error))
