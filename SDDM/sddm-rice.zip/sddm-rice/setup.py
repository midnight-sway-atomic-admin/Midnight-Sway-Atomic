#!/usr/bin/env python3
"""Install or remove the Fedora Sway Atomic SDDM rice, without backups."""
import argparse
import configparser
import fcntl
import io
import os
from pathlib import Path
import shlex
import shutil
import stat
import subprocess
import tempfile

SOURCE = Path(__file__).resolve().parent
ROOT = Path('/etc/sddm-rice')
DROPIN = Path('/etc/sddm.conf.d/99-sddm-rice.conf')
GREETER = Path('/etc/sway/sddm-greeter.config')
WRAPPER = Path('/usr/libexec/sddm-compositor-sway')
CONFIG_DIRS = [Path('/usr/lib/sddm/sddm.conf.d'), DROPIN.parent]
MAIN_CONFIG = Path('/etc/sddm.conf')
MARKER = '# Midnight Sway Atomic SDDM rice; managed by setup.py.\n'
CURSOR = 'sddm-rice-invisible'
LEGACY_END = '\n\n# SDDM rice: invisible compositor pointer.\nseat * xcursor_theme sddm-rice-invisible 24'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def protected(path):
    """Only operate below real, root-owned paths other users cannot change."""
    for part in [*reversed(path.parents), path]:
        try:
            info = part.lstat()
        except FileNotFoundError:
            continue
        require(stat.S_ISDIR(info.st_mode) or
                (part == path and stat.S_ISREG(info.st_mode) and info.st_nlink == 1),
                'Refusing a link or unexpected file type: ' + str(part))
        require(info.st_uid == 0 and not info.st_mode & 0o022,
                'Expected root ownership and no group/other writes: ' + str(part))


def parser(text=''):
    result = configparser.ConfigParser(interpolation=None, strict=False)
    result.optionxform = str
    result.read_string(text)
    return result


def value(config, section, key, fallback=''):
    return config.get(section, key, fallback=fallback).strip().strip('"')


def configuration(defaults, override=None):
    result = parser(defaults)
    for directory in CONFIG_DIRS:
        files = set(directory.glob('*.conf'))
        if override is not None and directory == DROPIN.parent:
            files.add(DROPIN)
        for path in sorted(files):
            if path == DROPIN:
                if override is not None:
                    result.read_string(override)
            else:
                protected(path)
                result.read_string(path.read_text())
    protected(MAIN_CONFIG)
    if MAIN_CONFIG.exists():
        result.read_string(MAIN_CONFIG.read_text())
    return result


def check_existing():
    protected(ROOT)
    protected(DROPIN)
    if ROOT.exists():
        require(ROOT.is_dir(), 'Expected a folder: ' + str(ROOT))
        for path in ROOT.rglob('*'):
            protected(path)
        require((ROOT / '.owner').is_file() and (ROOT / '.owner').read_text() == MARKER,
                'This folder is not a recognised installation: ' + str(ROOT))
    if DROPIN.exists() and not DROPIN.read_text().startswith(MARKER):
        # Recognise the old installer's own settings, without opening its backups.
        old = parser(DROPIN.read_text())
        allowed = {'Current': 'sddm-rice', 'ThemeDir': '/var/lib/sddm/themes',
                   'EnableAvatars': 'false', 'CursorTheme': CURSOR, 'CursorSize': '24'}
        require(not old.defaults() and old.sections() == ['Theme'] and
                value(old, 'Theme', 'Current') == 'sddm-rice' and
                all(key in allowed and value(old, 'Theme', key) == allowed[key]
                    for key in old['Theme']),
                'Existing override contains other settings; move them to a separate .conf file first: '
                + str(DROPIN))


def write(path, data, mode=0o644, gid=0):
    protected(path)
    fd, temporary = tempfile.mkstemp(prefix='.sddm-rice-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
            os.fchmod(stream.fileno(), mode)
            os.fchown(stream.fileno(), 0, gid)
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def install(check=False):
    check_existing()
    protected(GREETER)
    protected(WRAPPER)
    require(GREETER.is_file(), 'Missing Fedora greeter configuration: ' + str(GREETER))
    require('set -- --config /etc/sway/sddm-greeter.config "$@"' in WRAPPER.read_text(),
            'Unsupported Fedora greeter launcher; no files changed.')
    restorecon = shutil.which('restorecon')
    require(restorecon, 'restorecon is required for Fedora SELinux labels.')
    defaults = subprocess.run(['sddm', '--example-config'], check=True,
                              capture_output=True, text=True, timeout=15).stdout
    base = configuration(defaults)
    require(value(base, 'General', 'DisplayServer') == 'wayland' and
            shlex.split(value(base, 'Wayland', 'CompositorCommand')) == [str(WRAPPER)],
            'This setup requires Fedora\'s standard Wayland/Sway SDDM launcher.')
    environment = [item.strip() for item in value(base, 'General', 'GreeterEnvironment').split(',')
                   if item.strip() and not item.strip().startswith('XCURSOR_PATH=')]
    environment.append(f'XCURSOR_PATH={ROOT}/icons:/usr/share/icons:/usr/share/pixmaps')
    settings = {
        'General': {'GreeterEnvironment': ','.join(environment)},
        'Theme': {'ThemeDir': str(ROOT / 'themes'), 'Current': 'sddm-rice',
                  'EnableAvatars': 'false', 'CursorTheme': CURSOR, 'CursorSize': '24'},
        'Wayland': {'CompositorCommand': f'{WRAPPER} --config {ROOT}/greeter.config'},
    }
    proposed = parser()
    proposed.read_dict(settings)
    output = io.StringIO()
    proposed.write(output, space_around_delimiters=False)
    override = MARKER + output.getvalue()
    effective = configuration(defaults, override)
    for section, entries in settings.items():
        for key, expected in entries.items():
            require(value(effective, section, key) == expected,
                    f'{section}.{key} is overridden by another SDDM configuration; no files changed.')
    files = {Path('.owner'): MARKER.encode(),
             Path('greeter.config'): (f'include {GREETER}\n'
                                     f'seat * xcursor_theme {CURSOR} 24\n').encode()}
    for source in [*(SOURCE / 'theme').iterdir(), *(SOURCE / 'icons').rglob('*')]:
        require(not source.is_symlink(), 'Unexpected link in package: ' + str(source))
        if source.is_file():
            relative = (Path('themes/sddm-rice') / source.name if source.parent.name == 'theme'
                        else source.relative_to(SOURCE))
            files[relative] = source.read_bytes()
    require(all(Path(name) in files for name in ['themes/sddm-rice/Main.qml',
            'themes/sddm-rice/metadata.desktop', f'icons/{CURSOR}/index.theme',
            f'icons/{CURSOR}/cursors/left_ptr']), 'Theme or cursor files are missing.')
    original = GREETER.read_text()
    cleaned = original.rstrip()
    if cleaned.endswith(LEGACY_END):
        cleaned = cleaned[:-len(LEGACY_END)].rstrip() + '\n'
    else:
        cleaned = original
    if check:
        print('Check passed. No files changed. Installation uses one folder and one override.')
        return
    os.umask(0o022)
    for relative, data in files.items():
        target = ROOT / relative
        target.parent.mkdir(parents=True, exist_ok=True, mode=0o755)
        write(target, data)
    subprocess.run([restorecon, '-RF', str(ROOT)], check=True)
    DROPIN.parent.mkdir(exist_ok=True, mode=0o755)
    # Activate only after the complete theme and cursor data are in place.
    write(DROPIN, override.encode())
    subprocess.run([restorecon, str(DROPIN)], check=True)
    if cleaned != original:
        info = GREETER.stat()
        write(GREETER, cleaned.encode(), stat.S_IMODE(info.st_mode), info.st_gid)
        subprocess.run([restorecon, str(GREETER)], check=True)
        print('Removed the old installer\'s appended cursor setting. Old backups were not read.')
    print('Installed. Reboot when ready. Your current session has not been stopped.')


def uninstall():
    check_existing()
    require(not DROPIN.exists() or DROPIN.read_text().startswith(MARKER),
            'This is an older installation. Install this version before using its uninstaller.')
    DROPIN.unlink(missing_ok=True)
    if ROOT.exists():
        shutil.rmtree(ROOT)
    print('Removed this version\'s folder and override. Reboot when ready.')


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('action', choices=['install', 'uninstall'], nargs='?', default='install')
    args.add_argument('--check', action='store_true', help='check installation without changing files')
    options = args.parse_args()
    require(os.geteuid() == 0, 'Run this command with sudo from an administrator account.')
    require(not options.check or options.action == 'install', '--check applies to installation.')
    protected(ROOT.parent)
    # Lock the existing /etc directory: no lock file or persistent state is needed.
    fd = os.open(ROOT.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        install(options.check) if options.action == 'install' else uninstall()
    finally:
        os.close(fd)


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError, configparser.Error, subprocess.SubprocessError) as error:
        raise SystemExit(str(error))
