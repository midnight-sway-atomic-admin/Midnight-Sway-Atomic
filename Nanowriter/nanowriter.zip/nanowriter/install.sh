#!/usr/bin/env bash
set -euo pipefail
here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
destination="${XDG_DATA_HOME:-$HOME/.local/share}/nanowriter"
launcher="$HOME/.config/rofi/scripts/nanowriter.sh"

if [[ "$(uname -m)" != x86_64 ]]; then
    printf 'The included build requires x86_64 Linux. Source is included for rebuilding.\n' >&2
    exit 1
fi
command -v foot >/dev/null || { printf 'foot is required.\n' >&2; exit 1; }
"$here/bin/nanowriter" --version >/dev/null

install -D -m 0755 -- "$here/bin/nanowriter" "$destination/nanowriter"
install -D -m 0644 -- "$here/nanowriter.sh" "$launcher"
printf 'Installed Nanowriter. Your rofi launcher can use:\n'
printf 'bash %q\n' "$launcher"
