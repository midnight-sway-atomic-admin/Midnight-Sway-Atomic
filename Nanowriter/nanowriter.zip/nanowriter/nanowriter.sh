#!/usr/bin/env bash
set -euo pipefail

background=f5f3ee
foreground=000000
selection_foreground=315b8a
page_width=76
top_blank_rows=4

editor="${XDG_DATA_HOME:-$HOME/.local/share}/nanowriter/nanowriter"
writing_dir="$HOME/nanowriter-docs"
tiocsti=/proc/sys/dev/tty/legacy_tiocsti

if [[ ! -r "$tiocsti" || "$(<"$tiocsti")" != 0 ]]; then
    printf 'Refusing to launch: dev.tty.legacy_tiocsti must be 0.\n' >&2
    exit 1
fi

if [[ -L "$writing_dir" ]]; then
    printf 'Refusing symlinked Nanowriter directory: %s\n' "$writing_dir" >&2
    exit 1
fi

umask 077
mkdir -p -- "$writing_dir"

nanorc="$(mktemp "${XDG_RUNTIME_DIR:-${TMPDIR:-/tmp}}/nanowriter.XXXXXXXX")"
tmp_dir=
trap 'rm -f -- "$nanorc"; if [[ -n "$tmp_dir" ]]; then rmdir -- "$tmp_dir"; fi' EXIT
tmp_dir="$(mktemp -d "${nanorc}.tmp.XXXXXXXX")"

cat >"$nanorc" <<'NANORC'
set softwrap
set atblanks
set mouse
unset breaklonglines
set nohelp
set quickblank
set titlecolor normal,normal
set statuscolor normal,normal
set promptcolor normal,normal
set keycolor bold,normal,normal
set functioncolor normal,normal
NANORC

foot_options=(
    --title=Nanowriter
    --override=cursor.style=beam
    --override=cursor.beam-thickness=1
    --override=cursor.blink=no
    --override="colors-dark.background=$background"
    --override="colors-dark.foreground=$foreground"
    --override="colors-dark.selection-background=$background"
    --override="colors-dark.selection-foreground=$selection_foreground"
    --override="colors-dark.cursor=$background $foreground"
    --override=colors-dark.alpha=1.0
    --override="colors-light.background=$background"
    --override="colors-light.foreground=$foreground"
    --override="colors-light.selection-background=$background"
    --override="colors-light.selection-foreground=$selection_foreground"
    --override="colors-light.cursor=$background $foreground"
    --override=colors-light.alpha=1.0
)

# Prepare a private noexec tmpfs; Bubblewrap preserves its mount flags.
foot "${foot_options[@]}" \
    /usr/bin/unshare --user --map-root-user --mount --propagation private \
    /usr/bin/bash -e -c '
        # Read terminal settings after Foot has set them for this window.
        editor_env=()
        for name in TERM COLORTERM LANG LANGUAGE LC_ALL \
            LC_ADDRESS LC_COLLATE LC_CTYPE LC_IDENTIFICATION LC_MEASUREMENT \
            LC_MESSAGES LC_MONETARY LC_NAME LC_NUMERIC LC_PAPER LC_TELEPHONE LC_TIME; do
            if [[ -v $name ]]; then
                editor_env+=(--setenv "$name" "${!name}")
            fi
        done
        /usr/bin/mount -t tmpfs -o noexec,nosuid,nodev,mode=0700 tmpfs "$1"
        shift
        exec /usr/bin/bwrap --clearenv "${editor_env[@]}" "$@"
    ' nanowriter "$tmp_dir" \
    --unshare-user \
    --disable-userns \
    --uid "$UID" \
    --gid "$(id -g)" \
    --cap-drop ALL \
    --unshare-pid \
    --unshare-net \
    --unshare-ipc \
    --die-with-parent \
    --dev /dev \
    --bind "$tmp_dir" /tmp \
    --ro-bind /usr/lib64 /usr/lib64 \
    --symlink usr/lib64 /lib64 \
    --ro-bind-try /usr/lib/locale /usr/lib/locale \
    --ro-bind /usr/share/terminfo /usr/share/terminfo \
    --ro-bind "$editor" /app/nanowriter \
    --ro-bind "$nanorc" /run/nanowriter/nanorc \
    --bind "$writing_dir" "$writing_dir" \
    --chdir "$writing_dir" \
    --setenv HOME "$HOME" \
    --setenv PATH /usr/bin:/bin \
    --setenv TMPDIR /tmp \
    --setenv NANOWRITER_WIDTH "$page_width" \
    --setenv NANOWRITER_TOP "$top_blank_rows" \
    -- \
    /app/nanowriter --rcfile=/run/nanowriter/nanorc --operatingdir="$writing_dir" "$@"
