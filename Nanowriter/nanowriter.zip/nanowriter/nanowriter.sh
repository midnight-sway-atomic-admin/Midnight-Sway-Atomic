#!/usr/bin/env bash
# A separate, light-coloured nano profile for the rofi menu.
set -euo pipefail

# Edit these to adjust this window's colours (six hex digits, no #).
background=f5f3ee
foreground=000000
selection_foreground=315b8a

# Centered writing column and blank rows below the header.
# Physical spacing depends on your font size and display scaling.
page_width=76
top_blank_rows=4
export NANOWRITER_WIDTH="$page_width"
export NANOWRITER_TOP="$top_blank_rows"

editor="${XDG_DATA_HOME:-$HOME/.local/share}/nanowriter/nanowriter"
if [[ ! -x "$editor" ]]; then
    printf 'Nanowriter is not installed. Run install.sh from nanowriter.zip.\n' >&2
    exit 1
fi

# --rcfile isolates this session from both /etc/nanorc and your usual nanorc.
nanorc="$(mktemp "${XDG_RUNTIME_DIR:-${TMPDIR:-/tmp}}/nanowriter.XXXXXXXX")"
trap 'rm -f -- "$nanorc"' EXIT

cat > "$nanorc" <<'NANORC'
set softwrap
set atblanks
set mouse
unset breaklonglines
set nohelp
set quickblank

# Use the terminal's default black and off-white for the interface too.
set titlecolor normal,normal
set statuscolor normal,normal
set promptcolor normal,normal
set keycolor bold,normal,normal
set functioncolor normal,normal
NANORC

# Foot renamed its colour sections. Probe supported options without opening
# a window, and set both themes when available so either theme looks right.
if foot --config=/dev/null --check-config \
    --override="colors-dark.background=$background" \
    --override="colors-light.background=$background" >/dev/null 2>&1; then
    sections=(colors-dark colors-light)
else
    sections=(colors)
    if foot --config=/dev/null --check-config \
        --override="colors2.background=$background" >/dev/null 2>&1; then
        sections+=(colors2)
    fi
fi

foot_options=(
    --title="Nanowriter"
    --override=cursor.style=beam
    --override=cursor.beam-thickness=1
    --override=cursor.blink=no
)
for section in "${sections[@]}"; do
    foot_options+=(
        --override="$section.background=$background"
        --override="$section.foreground=$foreground"
        --override="$section.selection-background=$background"
        --override="$section.selection-foreground=$selection_foreground"
        --override="$section.alpha=1.0"
    )
done

# Ensure the cursor remains visible even if your normal foot theme sets it.
if foot --config=/dev/null --check-config \
    --override="${sections[0]}.cursor=$background $foreground" >/dev/null 2>&1; then
    for section in "${sections[@]}"; do
        foot_options+=(--override="$section.cursor=$background $foreground")
    done
else
    foot_options+=(--override="cursor.color=$background $foreground")
fi

# Keep the temporary configuration until foot and nano have exited.
foot "${foot_options[@]}" "$editor" --rcfile="$nanorc" "$@"
