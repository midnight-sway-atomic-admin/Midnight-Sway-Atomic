(() => {
  let overlay = null;
  let hideTimer = null;

  function isEditableTarget(target) {
    if (!(target instanceof Element)) {
      return false;
    }

    return (
      target.closest("input, textarea, select") !== null ||
      target.isContentEditable === true ||
      target.closest('[contenteditable]:not([contenteditable="false"])') !== null
    );
  }

  function getVideos() {
    return Array.from(document.querySelectorAll("video"));
  }

  function createOverlay() {
    overlay = document.createElement("div");

    overlay.style.cssText = [
      "position: fixed",
      "top: 10px",
      "right: 10px",
      "background: rgba(0, 0, 0, 0.7)",
      "color: white",
      "padding: 8px 12px",
      "border-radius: 4px",
      "z-index: 2147483647",
      "font-size: 16px",
      "font-family: sans-serif",
      "transition: opacity 0.5s ease",
      "opacity: 0",
      "pointer-events: none"
    ].join("; ");

    (document.body || document.documentElement).appendChild(overlay);
  }

  function showSpeed(rate) {
    if (!overlay || !overlay.isConnected) {
      createOverlay();
    }

    overlay.textContent = `Speed: ${rate.toFixed(1)}x`;
    overlay.style.opacity = "1";

    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      overlay.style.opacity = "0";
    }, 1000);
  }

  function clampPlaybackRate(rate) {
    return Math.min(16, Math.max(0.5, rate));
  }

  window.addEventListener(
    "keydown",
    (event) => {
      if (
        !event.ctrlKey ||
        event.altKey ||
        event.metaKey ||
        event.shiftKey ||
        (event.key !== "ArrowUp" && event.key !== "ArrowDown") ||
        isEditableTarget(event.target)
      ) {
        return;
      }

      const videos = getVideos();

      if (videos.length === 0) {
        return;
      }

      const delta = event.key === "ArrowUp" ? 0.5 : -0.5;
      let displayedRate = null;

      for (const video of videos) {
        const newRate = clampPlaybackRate(video.playbackRate + delta);
        video.playbackRate = newRate;

        if (displayedRate === null) {
          displayedRate = newRate;
        }
      }

      showSpeed(displayedRate);

      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
    },
    true
  );
})();
