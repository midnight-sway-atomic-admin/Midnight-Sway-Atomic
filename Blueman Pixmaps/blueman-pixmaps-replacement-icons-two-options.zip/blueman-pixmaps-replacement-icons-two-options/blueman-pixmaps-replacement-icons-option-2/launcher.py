#!/usr/bin/python3
"""Use this directory's SVG meters with the installed Blueman manager."""
from pathlib import Path
import importlib
import runpy
from tempfile import TemporaryDirectory


def prepare_pixmaps(custom, original, destination):
    """Provide a real directory for both os.path.join and pathlib callers."""
    custom, original, destination = map(Path, (custom, original, destination))
    for entry in original.iterdir():
        (destination / entry.name).symlink_to(entry.resolve())
    for family in ('battery', 'rssi', 'tpl'):
        for level in range(10, 101, 10):
            name = f'blueman-{family}-{level}'
            svg = custom / (name + '.svg')
            if svg.is_file():
                alias = destination / (name + '.png')
                alias.unlink(missing_ok=True)
                # GdkPixbuf detects SVG content even under a .png filename.
                alias.symlink_to(svg.resolve())
    return destination


def main():
    meters = importlib.import_module('blueman.gui.manager.ManagerDeviceList')
    original = meters.PIXMAP_PATH
    with TemporaryDirectory(prefix='blueman-midnight-') as temporary:
        meters.PIXMAP_PATH = prepare_pixmaps(
            Path(__file__).resolve().parent, original, temporary)
        try:
            runpy.run_path('/usr/bin/blueman-manager', run_name='__main__')
        finally:
            meters.PIXMAP_PATH = original


if __name__ == '__main__':
    main()
