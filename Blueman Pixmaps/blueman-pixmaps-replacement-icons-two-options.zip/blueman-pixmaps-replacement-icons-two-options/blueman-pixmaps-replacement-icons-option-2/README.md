# Blueman meters — option 2

Thin SVG replacements for all three meters in Blueman's Bluetooth Manager: battery, RSSI (received signal strength), and TPL (transmit power). Each meter has ten states. Battery outlines and TPL use `#8a97bf`, battery fill uses `#c7d0ea`, and RSSI uses `#bfb28a`.

Option 1 hides RSSI and TPL with transparent placeholders for a battery-only appearance. Both options share the same battery icons. Their folders can both be installed; the most recently installed option becomes active.

## Install

Requires the system Blueman package and its SVG loader. Run inside this folder as your normal user, without `sudo`:

```sh
/usr/bin/python3 setup.py
```

This folder is installed as `~/.local/share/themes/blueman/blueman-pixmaps-replacement-icons-option-2/`, alongside your existing `gtk.css`, which is preserved. User-local menu, D-Bus, and systemd overrides launch this option. `XDG_DATA_HOME` and `XDG_CONFIG_HOME` are respected; no username is hard-coded. The downloaded folder can be removed afterward.

Quit Bluetooth Manager completely, then reopen it from the application menu or tray.

For a shell launcher, rofi script, or Sway binding that directly invokes `blueman-manager`, use this command. `GTK_THEME=blueman` selects your Blueman GTK theme:

```sh
GTK_THEME=blueman /usr/bin/python3 "${XDG_DATA_HOME:-$HOME/.local/share}/themes/blueman/blueman-pixmaps-replacement-icons-option-2/launcher.py"
```

## Remove

Quit Bluetooth Manager, then run:

```sh
/usr/bin/python3 "${XDG_DATA_HOME:-$HOME/.local/share}/themes/blueman/blueman-pixmaps-replacement-icons-option-2/setup.py" --remove
```

Removal removes the installed meter options, restores backed-up user files, and preserves subsequent edits and `gtk.css`. The private restoration record is stored at `~/.config/blueman-midnight/installation.json`, outside the theme directory; don't commit it.

If an earlier installation exists under `~/.local/share/blueman-midnight/`, remove it with that folder's `setup.py --remove` before installing this version.

The launcher redirects meter loading to these SVGs while running the installed Blueman manager. This depends on Blueman internals and may need adjustment after updates. [Blueman source](https://github.com/blueman-project/blueman).

## Original meters

![Original Blueman meter icons for comparison](the-hideous-originals.png)
