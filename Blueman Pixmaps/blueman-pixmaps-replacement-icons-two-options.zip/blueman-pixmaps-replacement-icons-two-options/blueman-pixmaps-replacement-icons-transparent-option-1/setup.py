#!/usr/bin/python3
"""Install/remove the Midnight Blueman meters for the current user only."""
from pathlib import Path
import argparse
import base64
import hashlib
import json
import os
import subprocess
import tempfile


OPTION_DIRECTORY = 'blueman-pixmaps-replacement-icons-transparent-option-1'
OPTION_DIRECTORIES = ('blueman-pixmaps-replacement-icons-transparent-option-1',
                      'blueman-pixmaps-replacement-icons-option-2')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def quote_argument(value):
    # Both Desktop Entry and systemd Exec lines are argument lists, not shells.
    value = str(value)
    if any(ch in value for ch in '\n\r\0'):
        raise ValueError('A path contains an unsupported control character.')
    return '"' + value.replace('\\', '\\\\').replace('"', '\\"') + '"'


def atomic_write(path, data, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.midnight-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def files_to_install(source, data_home, config_home, vendor_desktop):
    destination = data_home / 'themes/blueman' / OPTION_DIRECTORY
    launch = destination / 'launcher.py'
    command = '/usr/bin/python3 ' + quote_argument(launch)
    # Desktop Entry applies a general string-unescape pass, then Exec parsing.
    desktop_command = command.replace('\\', '\\\\').replace('$', '\\\\$').replace('`', '\\\\`').replace('%', '%%')
    systemd_command = command.replace('%', '%%').replace('$', '$$')
    names = [f'blueman-{family}-{level}.svg'
             for family in ('battery', 'rssi', 'tpl') for level in range(10, 101, 10)]
    names += ['launcher.py', 'setup.py', 'README.md', '.gitignore', 'the-hideous-originals.png']
    if (source / 'preview-transparent.png').is_file():
        names.append('preview-transparent.png')
    files = {destination / name: (source / name).read_bytes() for name in names}
    desktop = vendor_desktop.read_text()
    lines = desktop.splitlines()
    section = None
    updated = []
    found_exec = False
    for line in lines:
        if line.startswith('['):
            section = line
        if section == '[Desktop Entry]' and line.startswith('Exec='):
            line = 'Exec=' + desktop_command
            found_exec = True
        elif section == '[Desktop Entry]' and line.startswith('DBusActivatable='):
            line = 'DBusActivatable=false'
        updated.append(line)
    if not found_exec:
        raise ValueError('The installed Bluetooth Manager desktop entry has no Exec line.')
    files[data_home / 'applications/blueman-manager.desktop'] = ('\n'.join(updated) + '\n').encode()
    files[config_home / 'systemd/user/blueman-manager.service.d/90-midnight-icons.conf'] = (
        '[Service]\nExecStart=\nExecStart=' + systemd_command + '\n').encode()
    files[data_home / 'dbus-1/services/org.blueman.Manager.service'] = (
        '[D-BUS Service]\nName=org.blueman.Manager\nExec=' + command +
        '\nSystemdService=blueman-manager.service\n').encode()
    return files


def install(source, data_home, config_home, vendor_desktop):
    legacy_state = data_home / 'blueman-midnight/installation.json'
    if legacy_state.exists():
        command = '/usr/bin/python3 ' + quote_argument(legacy_state.parent / 'setup.py') + ' --remove'
        raise RuntimeError('Remove the previous installation before installing in the theme directory: ' + command)
    state_path = config_home / 'blueman-midnight/installation.json'
    if state_path.is_symlink() or (state_path.exists() and not state_path.is_file()):
        raise RuntimeError(f'Cannot use a symlink or non-file as the installation record: {state_path}')
    old_state = json.loads(state_path.read_text()) if state_path.exists() else {}
    files = files_to_install(source, data_home, config_home, vendor_desktop)
    state = dict(old_state)
    for path, content in files.items():
        key = str(path)
        if path.is_symlink() or (path.exists() and not path.is_file()):
            raise RuntimeError(f'Cannot replace a symlink or non-file: {path}')
        if key in old_state:
            if not path.exists() or digest(path.read_bytes()) != old_state[key]['after']:
                raise RuntimeError(f'This installed file was subsequently changed: {path}')
            before = old_state[key]['before']
            mode = old_state[key]['mode']
        else:
            before = base64.b64encode(path.read_bytes()).decode() if path.exists() else None
            mode = (path.stat().st_mode & 0o777) if path.exists() else 0o644
        state[key] = {'before': before, 'mode': mode, 'after': digest(content)}
    # Save restoration data before changing any tracked file.
    atomic_write(state_path, json.dumps(state, indent=2).encode(), 0o600)
    for path, content in files.items():
        atomic_write(path, content)


def remove(data_home, config_home):
    state_path = config_home / 'blueman-midnight/installation.json'
    if state_path.is_symlink():
        raise RuntimeError(f'Cannot use a symlink as the installation record: {state_path}')
    if not state_path.exists():
        raise RuntimeError('No Midnight Blueman installation record was found.')
    state = json.loads(state_path.read_text())
    retained = {}
    destination = data_home / 'themes/blueman'
    keep_runtime = any(
        not Path(name).is_relative_to(destination)
        and Path(name).exists()
        and (Path(name).is_symlink() or digest(Path(name).read_bytes()) != entry['after'])
        for name, entry in state.items())
    # Restore activation files before removing the launcher they refer to.
    ordered = sorted(state.items(), key=lambda item: Path(item[0]).is_relative_to(destination))
    for name, entry in ordered:
        path = Path(name)
        if keep_runtime and path.is_relative_to(destination):
            retained[name] = entry
            continue
        if not path.exists():
            continue
        if path.is_symlink() or digest(path.read_bytes()) != entry['after']:
            retained[name] = entry
            print(f'Kept a file changed after installation: {path}')
            continue
        if entry['before'] is None:
            path.unlink()
        else:
            atomic_write(path, base64.b64decode(entry['before']), entry['mode'])
    if retained:
        atomic_write(state_path, json.dumps(retained, indent=2).encode(), 0o600)
        if keep_runtime:
            print('Kept the launcher and SVGs because a modified launch entry may still use them.')
    else:
        state_path.unlink()
        for name in OPTION_DIRECTORIES:
            try:
                (destination / name).rmdir()
            except OSError:
                pass
        try:
            state_path.parent.rmdir()
        except OSError:
            pass
    return not retained


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--remove', action='store_true', help='Restore the previous user launchers.')
    args = parser.parse_args()
    if os.geteuid() == 0:
        parser.error('Run this as your normal desktop user, without sudo.')
    data_home = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local/share').absolute()
    config_home = Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config').absolute()
    try:
        if args.remove:
            complete = remove(data_home, config_home)
        else:
            if not Path('/usr/bin/blueman-manager').is_file():
                parser.error('The system Blueman manager is not installed at /usr/bin/blueman-manager.')
            install(Path(__file__).resolve().parent, data_home, config_home,
                    Path('/usr/share/applications/blueman-manager.desktop'))
    except (OSError, ValueError, RuntimeError) as error:
        parser.error(str(error))
    result = subprocess.run(['systemctl', '--user', 'daemon-reload'], check=False)
    if result.returncode:
        print('Log out and back in to reload the user service configuration.')
    print(('Removed.' if complete else 'Some modified files were retained.')
          if args.remove else 'Installed for your user account.')
    print('Quit the Bluetooth Manager window completely, then reopen it from the menu or tray.')


if __name__ == '__main__':
    main()
