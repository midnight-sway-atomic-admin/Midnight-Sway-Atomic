(() => {
  "use strict";

  const TOTAL_CELLS = 60;
  const STORAGE_KEY = "speedDialData";
  const URL_SCHEME_PATTERN = /^[a-z][a-z\d+.-]*:/i;

  let dialData = [];
  let currentIndex = null;
  let returnFocusToEdit = false;
  const modal = document.getElementById("modal");

  function normalizeUrl(value) {
    const rawUrl = String(value || "").trim();
    if (!rawUrl) return "";

    const candidate = URL_SCHEME_PATTERN.test(rawUrl) ? rawUrl : `https://${rawUrl}`;

    try {
      const url = new URL(candidate);
      return url.protocol === "http:" || url.protocol === "https:" ? url.href : "";
    } catch (_error) {
      return "";
    }
  }

  function normalizeCell(value) {
    const cell = value && typeof value === "object" ? value : {};

    return {
      text: String(cell.text || "").trim(),
      url: normalizeUrl(cell.url)
    };
  }

  function normalizeData(data) {
    const source = Array.isArray(data) ? data : [];
    return Array.from({ length: TOTAL_CELLS }, (_cell, index) => normalizeCell(source[index]));
  }

  function loadData() {
    try {
      dialData = normalizeData(JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"));
    } catch (_error) {
      dialData = normalizeData([]);
    }
  }

  function saveData() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(dialData));
  }

  function renderCells() {
    const grid = document.getElementById("grid");
    grid.replaceChildren();

    for (let i = 0; i < TOTAL_CELLS; i++) {
      const cellData = dialData[i];
      const wrapper = document.createElement("div");
      const cell = document.createElement(cellData.url ? "a" : "button");
      const isEmpty = !cellData.text && !cellData.url;
      const label = document.createElement("span");

      wrapper.className = "cell-wrapper";
      cell.className = isEmpty ? "cell is-empty" : "cell";
      cell.dataset.index = i;
      label.className = isEmpty ? "cell-plus" : "cell-label";
      label.textContent = cellData.text || cellData.url || "+";
      cell.appendChild(label);

      if (isEmpty) {
        cell.setAttribute("aria-label", `Add shortcut in slot ${i + 1}`);
        label.setAttribute("aria-hidden", "true");
      } else {
        cell.title = cellData.text || cellData.url;
      }

      if (cellData.url) {
        cell.href = cellData.url;
      } else {
        cell.type = "button";
        cell.addEventListener("click", openEditor);
      }

      wrapper.appendChild(cell);

      if (!isEmpty) {
        const edit = document.createElement("button");
        const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        const path = document.createElementNS("http://www.w3.org/2000/svg", "path");

        edit.type = "button";
        edit.className = "cell-edit";
        edit.dataset.index = i;
        edit.title = "Edit shortcut";
        edit.setAttribute("aria-label", `Edit shortcut: ${cellData.text || cellData.url}`);
        edit.addEventListener("click", openEditor);
        icon.setAttribute("viewBox", "0 0 24 24");
        icon.setAttribute("aria-hidden", "true");
        icon.setAttribute("focusable", "false");
        path.setAttribute("d", "M15.5 5.5l3 3M4 20l4.5-1 12-12a2.12 2.12 0 0 0-3-3l-12 12L4 20Z");
        icon.appendChild(path);
        edit.appendChild(icon);
        wrapper.appendChild(edit);
      }

      grid.appendChild(wrapper);
    }
  }

  function openEditor(event) {
    currentIndex = Number(event.currentTarget.dataset.index);
    returnFocusToEdit = event.currentTarget.classList.contains("cell-edit");
    const cellData = dialData[currentIndex];

    document.getElementById("cellText").value = cellData.text;
    document.getElementById("cellUrl").value = cellData.url;
    modal.showModal();
  }

  function closeModal() {
    modal.close();
  }

  modal.addEventListener("close", function() {
    if (currentIndex !== null) {
      const cell = document.querySelector(`.cell[data-index="${currentIndex}"]`);
      const edit = document.querySelector(`.cell-edit[data-index="${currentIndex}"]`);
      (returnFocusToEdit ? edit || cell : cell)?.focus();
    }
  });

  document.getElementById("editorForm").addEventListener("submit", function(event) {
    event.preventDefault();
    const text = document.getElementById("cellText").value.trim();
    const rawUrl = document.getElementById("cellUrl").value.trim();
    const url = normalizeUrl(rawUrl);

    if (rawUrl && !url) {
      alert("Only http:// and https:// URLs are supported.");
      return;
    }

    dialData[currentIndex] = { text, url };
    saveData();
    renderCells();
    closeModal();
  });

  document.getElementById("cancelBtn").addEventListener("click", closeModal);

  document.getElementById("exportBtn").addEventListener("click", function() {
    const jsonData = JSON.stringify(dialData, null, 2);
    prompt("Copy your speed dial data:", jsonData);
  });

  document.getElementById("importBtn").addEventListener("click", function() {
    const importText = prompt("Paste your speed dial JSON data:");
    if (!importText) return;

    try {
      const imported = JSON.parse(importText);
      if (!Array.isArray(imported)) {
        alert("Invalid data format.");
        return;
      }

      dialData = normalizeData(imported);
      saveData();
      renderCells();
    } catch (_error) {
      alert("Error parsing JSON.");
    }
  });

  loadData();
  renderCells();
})();
