(() => {
  "use strict";

  const TOTAL_CELLS = 60;
  const STORAGE_KEY = "speedDialData";
  const URL_SCHEME_PATTERN = /^[a-z][a-z\d+.-]*:/i;

  let dialData = [];
  let currentIndex = null;
  let originalCell = null;
  let writePending = false;
  let returnFocusToEdit = false;
  const modal = document.getElementById("modal");
  const changes = new BroadcastChannel("midnight-speed-dial-changes");

  function normalizeUrl(value) {
    const rawUrl = String(value || "").trim();
    if (!rawUrl) return "";

    const candidate = URL_SCHEME_PATTERN.test(rawUrl) ? rawUrl : `https://${rawUrl}`;

    try {
      const url = new URL(candidate);
      return url.protocol === "http:" || url.protocol === "https:" ? url.href : "";
    } catch (_error) {
      return "";
    }
  }

  function normalizeCell(value) {
    const cell = value && typeof value === "object" ? value : {};

    return {
      text: String(cell.text || "").trim(),
      url: normalizeUrl(cell.url)
    };
  }

  function normalizeData(data) {
    const source = Array.isArray(data) ? data : [];
    return Array.from({ length: TOTAL_CELLS }, (_cell, index) => normalizeCell(source[index]));
  }

  function transaction(database, mode, change) {
    return new Promise((resolve, reject) => {
      const tx = database.transaction("shortcuts", mode);
      const store = tx.objectStore("shortcuts");
      const request = store.get(STORAGE_KEY);
      let result;
      let failure;
      request.onsuccess = () => {
        try {
          // The first committed transaction imports the existing 1.5 data.
          // Later tabs always read the authoritative IndexedDB record.
          const latest = request.result === undefined
            ? normalizeData(JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"))
            : normalizeData(request.result);
          result = change ? change(latest) : latest;
          if (mode === "readwrite") store.put(result, STORAGE_KEY);
        } catch (error) {
          failure = error;
          tx.abort();
        }
      };
      tx.oncomplete = () => resolve(result);
      tx.onabort = () => reject(failure || tx.error || new Error("Shortcut storage is unavailable."));
    });
  }

  const databaseReady = new Promise((resolve, reject) => {
    const request = indexedDB.open("midnight-speed-dial", 1);
    request.onupgradeneeded = () => request.result.createObjectStore("shortcuts");
    request.onerror = () => reject(request.error);
    request.onblocked = () => reject(new Error("Close older Speed Dial tabs and reopen this tab."));
    request.onsuccess = () => {
      request.result.onversionchange = () => request.result.close();
      resolve(request.result);
    };
  }).then(async database => {
    await transaction(database, "readwrite");
    return database;
  });

  async function readData() {
    return transaction(await databaseReady, "readonly");
  }

  async function loadData() {
    dialData = await readData();
    renderCells();
  }

  async function saveData(change) {
    // IndexedDB serializes read/write transactions across tabs. Read, merge
    // and write in one transaction, without a cached localStorage snapshot.
    await transaction(await databaseReady, "readwrite", change);
    changes.postMessage("changed");
    await loadData();
  }

  function setWritePending(pending) {
    writePending = pending;
    for (const id of ["saveBtn", "cancelBtn", "cellText", "cellUrl", "importBtn", "exportBtn"]) {
      document.getElementById(id).disabled = pending;
    }
  }

  function renderCells() {
    const grid = document.getElementById("grid");
    grid.replaceChildren();

    for (let i = 0; i < TOTAL_CELLS; i++) {
      const cellData = dialData[i];
      const wrapper = document.createElement("div");
      const cell = document.createElement(cellData.url ? "a" : "button");
      const isEmpty = !cellData.text && !cellData.url;
      const label = document.createElement("span");

      wrapper.className = "cell-wrapper";
      cell.className = isEmpty ? "cell is-empty" : "cell";
      cell.dataset.index = i;
      label.className = isEmpty ? "cell-plus" : "cell-label";
      label.textContent = cellData.text || cellData.url || "+";
      cell.appendChild(label);

      if (isEmpty) {
        cell.setAttribute("aria-label", `Add shortcut in slot ${i + 1}`);
        label.setAttribute("aria-hidden", "true");
      } else {
        cell.title = cellData.text || cellData.url;
      }

      if (cellData.url) {
        cell.href = cellData.url;
      } else {
        cell.type = "button";
        cell.addEventListener("click", openEditor);
      }

      wrapper.appendChild(cell);

      if (!isEmpty) {
        const edit = document.createElement("button");
        const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        const path = document.createElementNS("http://www.w3.org/2000/svg", "path");

        edit.type = "button";
        edit.className = "cell-edit";
        edit.dataset.index = i;
        edit.title = "Edit shortcut";
        edit.setAttribute("aria-label", `Edit shortcut: ${cellData.text || cellData.url}`);
        edit.addEventListener("click", openEditor);
        icon.setAttribute("viewBox", "0 0 24 24");
        icon.setAttribute("aria-hidden", "true");
        icon.setAttribute("focusable", "false");
        path.setAttribute("d", "M15.5 5.5l3 3M4 20l4.5-1 12-12a2.12 2.12 0 0 0-3-3l-12 12L4 20Z");
        icon.appendChild(path);
        edit.appendChild(icon);
        wrapper.appendChild(edit);
      }

      grid.appendChild(wrapper);
    }
  }

  function openEditor(event) {
    if (writePending) return;
    currentIndex = Number(event.currentTarget.dataset.index);
    returnFocusToEdit = event.currentTarget.classList.contains("cell-edit");
    const cellData = dialData[currentIndex];
    originalCell = { ...cellData };

    document.getElementById("cellText").value = cellData.text;
    document.getElementById("cellUrl").value = cellData.url;
    modal.showModal();
  }

  function closeModal() {
    if (!writePending) modal.close();
  }

  modal.addEventListener("cancel", event => {
    if (writePending) event.preventDefault();
  });

  modal.addEventListener("close", function() {
    if (currentIndex !== null) {
      const cell = document.querySelector(`.cell[data-index="${currentIndex}"]`);
      const edit = document.querySelector(`.cell-edit[data-index="${currentIndex}"]`);
      (returnFocusToEdit ? edit || cell : cell)?.focus();
    }
  });

  document.getElementById("editorForm").addEventListener("submit", async function(event) {
    event.preventDefault();
    if (writePending || currentIndex === null) return;
    const text = document.getElementById("cellText").value.trim();
    const rawUrl = document.getElementById("cellUrl").value.trim();
    const url = normalizeUrl(rawUrl);

    if (rawUrl && !url) {
      alert("Only http:// and https:// URLs are supported.");
      return;
    }

    const index = currentIndex;
    const before = originalCell;
    let saved = false;
    setWritePending(true);
    try {
      await saveData(latest => {
        if (latest[index].text !== before.text || latest[index].url !== before.url) {
          throw new Error("This shortcut changed in another tab. Cancel and reopen it before saving.");
        }
        latest[index] = { text, url };
        return latest;
      });
      saved = true;
    } catch (error) {
      alert(`Could not save shortcut: ${error.message}`);
    } finally {
      setWritePending(false);
    }
    if (saved) closeModal();
  });

  document.getElementById("cancelBtn").addEventListener("click", closeModal);

  document.getElementById("exportBtn").addEventListener("click", async function() {
    if (writePending) return;
    try {
      prompt("Copy your speed dial data:", JSON.stringify(await readData(), null, 2));
    } catch (error) {
      alert(`Could not read saved shortcuts: ${error.message}`);
    }
  });

  document.getElementById("importBtn").addEventListener("click", async function() {
    if (writePending) return;
    const importText = prompt("Paste your speed dial JSON data:");
    if (!importText) return;

    let imported;
    try {
      imported = JSON.parse(importText);
      if (!Array.isArray(imported)) {
        alert("Invalid data format.");
        return;
      }

    } catch (_error) {
      alert("Error parsing JSON.");
      return;
    }
    setWritePending(true);
    try {
      // Import deliberately replaces all cells, serialized with ordinary edits.
      await saveData(() => normalizeData(imported));
    } catch (error) {
      alert(`Could not import shortcuts: ${error.message}`);
    } finally {
      setWritePending(false);
    }
  });

  changes.onmessage = () => {
    void loadData().catch(error => alert(`Could not refresh shortcuts: ${error.message}`));
  };

  setWritePending(true);
  loadData().catch(error => alert(`Could not load shortcuts: ${error.message}`))
    .finally(() => setWritePending(false));
})();
