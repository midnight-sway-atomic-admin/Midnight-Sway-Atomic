(() => {
  "use strict";

  let overlay = null;
  let hideTimer = null;

  function isEditableTarget(target) {
    return (
      target instanceof Element &&
      target.closest('input, textarea, select, [contenteditable]:not([contenteditable="false"])') !== null
    );
  }

  function createOverlay() {
    overlay = document.createElement("div");

    overlay.style.cssText = [
      "position: fixed",
      "top: 50%",
      "left: 50%",
      "transform: translate(-50%, -50%)",
      "background: rgba(0, 0, 0, 0.7)",
      "color: white",
      "padding: 8px 12px",
      "border-radius: 4px",
      "z-index: 2147483647",
      "font-size: 16px",
      "font-family: sans-serif",
      "transition: opacity 0.5s ease",
      "opacity: 0",
      "pointer-events: none"
    ].join("; ");

    document.body.appendChild(overlay);
  }

  function positionOverlay(video) {
    // Resolve the current container each time; YouTube can replace its player.
    const player = video && video.closest("#movie_player, .html5-video-player");
    const bounds = player && player.getBoundingClientRect();
    const canAnchor =
      player &&
      player.isConnected &&
      bounds.width > 0 &&
      bounds.height > 0 &&
      window.getComputedStyle(player).position !== "static";

    // Never change YouTube's layout to establish a positioning reference.
    const parent = canAnchor ? player : document.body;
    overlay.style.position = canAnchor ? "absolute" : "fixed";

    if (overlay.parentElement !== parent) {
      parent.appendChild(overlay);
    }
  }

  function showSpeed(rate, video) {
    if (!overlay || !overlay.isConnected) {
      createOverlay();
    }

    positionOverlay(video);
    overlay.textContent = `Speed: ${rate.toFixed(1)}x`;
    overlay.style.opacity = "1";

    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      overlay.style.opacity = "0";
    }, 1000);
  }

  function clampPlaybackRate(rate) {
    return Math.min(16, Math.max(0.5, rate));
  }

  function getVisibleArea(video) {
    if (
      typeof video.checkVisibility === "function" &&
      !video.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })
    ) {
      return 0;
    }

    const bounds = video.getBoundingClientRect();
    const width = Math.max(
      0,
      Math.min(bounds.right, window.innerWidth) - Math.max(bounds.left, 0)
    );
    const height = Math.max(
      0,
      Math.min(bounds.bottom, window.innerHeight) - Math.max(bounds.top, 0)
    );

    return width * height;
  }

  window.addEventListener(
    "keydown",
    (event) => {
      if (
        !event.isTrusted ||
        !event.ctrlKey ||
        event.altKey ||
        event.metaKey ||
        event.shiftKey ||
        (event.key !== "ArrowUp" && event.key !== "ArrowDown") ||
        isEditableTarget(event.target)
      ) {
        return;
      }

      const videos = document.querySelectorAll("video");

      if (videos.length === 0) {
        return;
      }

      const delta = event.key === "ArrowUp" ? 0.5 : -0.5;
      let displayedVideo = videos[0];
      let largestVisibleArea = 0;

      for (const video of videos) {
        const newRate = clampPlaybackRate(video.playbackRate + delta);
        video.playbackRate = newRate;

        // Prefer the visible player over hidden or preloaded video elements.
        const visibleArea = getVisibleArea(video);

        if (visibleArea > largestVisibleArea) {
          displayedVideo = video;
          largestVisibleArea = visibleArea;
        }
      }

      showSpeed(
        displayedVideo.playbackRate,
        largestVisibleArea > 0 ? displayedVideo : null
      );

      event.preventDefault();
      event.stopImmediatePropagation();
    },
    true
  );
})();
