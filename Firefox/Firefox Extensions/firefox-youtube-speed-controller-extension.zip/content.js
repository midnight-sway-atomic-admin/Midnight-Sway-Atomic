(() => {
  "use strict";

  let overlay = null;
  let hideTimer = null;
  let spaceHeld = false;

  function isEditableTarget(target) {
    return (
      target instanceof Element &&
      target.closest('input, textarea, select, [contenteditable]:not([contenteditable="false"])') !== null
    );
  }

  function createOverlay() {
    overlay = document.createElement("div");

    overlay.style.cssText = [
      "position: fixed",
      "top: 50%",
      "left: 50%",
      "transform: translate(-50%, -50%)",
      "background: rgba(0, 0, 0, 0.7)",
      "color: white",
      "padding: 8px 12px",
      "border-radius: 4px",
      "z-index: 2147483647",
      "font-size: 16px",
      "font-family: sans-serif",
      "transition: opacity 0.5s ease",
      "opacity: 0",
      "pointer-events: none"
    ].join("; ");

    document.body.appendChild(overlay);
  }

  function positionOverlay(video) {
    // Resolve the current container each time; YouTube can replace its player.
    const player = video && video.closest("#movie_player, .html5-video-player");
    const bounds = player && player.getBoundingClientRect();
    const canAnchor =
      player &&
      player.isConnected &&
      bounds.width > 0 &&
      bounds.height > 0 &&
      window.getComputedStyle(player).position !== "static";

    // Never change YouTube's layout to establish a positioning reference.
    const parent = canAnchor ? player : document.body;
    overlay.style.position = canAnchor ? "absolute" : "fixed";

    if (overlay.parentElement !== parent) {
      parent.appendChild(overlay);
    }
  }

  function showSpeed(rate, video) {
    if (!overlay || !overlay.isConnected) {
      createOverlay();
    }

    positionOverlay(video);
    overlay.textContent = `Speed: ${rate.toFixed(1)}x`;
    overlay.style.opacity = "1";

    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      overlay.style.opacity = "0";
    }, 1000);
  }

  function clampPlaybackRate(rate) {
    return Math.min(16, Math.max(0.5, rate));
  }

  function getVisibleArea(video) {
    if (
      typeof video.checkVisibility === "function" &&
      !video.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })
    ) {
      return 0;
    }

    const bounds = video.getBoundingClientRect();
    const width = Math.max(
      0,
      Math.min(bounds.right, window.innerWidth) - Math.max(bounds.left, 0)
    );
    const height = Math.max(
      0,
      Math.min(bounds.bottom, window.innerHeight) - Math.max(bounds.top, 0)
    );

    return width * height;
  }

  function blockPointerHold(event) {
    if (
      !event.isTrusted ||
      (event.type !== "touchstart" && event.button !== 0) ||
      !(event.target instanceof Element)
    ) {
      return;
    }

    // YouTube attaches its hold detector to the video container. Keep presses
    // on the timeline, menus, buttons, captions and other overlays untouched.
    const surface = event.target.closest(".html5-video-container");

    if (
      surface &&
      surface.closest("#movie_player, .html5-video-player") &&
      !surface.closest("a[href], ytd-video-preview")
    ) {
      // Block YouTube's hold detector. handleVideoClick supplies play/pause:
      // YouTube's own surface-click handler can depend on this initial press.
      event.stopImmediatePropagation();
    }
  }

  function toggleVideoPlayback(video) {
    if (video.paused) {
      video.play().catch(() => {
        // Playback can be denied or interrupted by navigation; allow retry.
      });
    } else {
      video.pause();
    }
  }

  function handleVideoClick(event) {
    if (
      !event.isTrusted ||
      event.button !== 0 ||
      !(event.target instanceof Element)
    ) {
      return;
    }

    const surface = event.target.closest(".html5-video-container");
    const player = surface && surface.closest("#movie_player, .html5-video-player");

    if (!player || surface.closest("a[href], ytd-video-preview")) {
      return;
    }

    const playButton = player.querySelector("button.ytp-play-button");
    const video = playButton ? null : getSpacebarVideo(event.target);

    if (!playButton && !video) {
      return;
    }

    // Use the player's button so native playback state and controls stay in
    // sync. Consume the surface click to prevent a second native toggle.
    // Leave the separate dblclick and contextmenu events to YouTube.
    event.preventDefault();
    event.stopImmediatePropagation();

    if (playButton) {
      playButton.click();
    } else {
      toggleVideoPlayback(video);
    }
  }

  function getSpacebarVideo(target) {
    if (
      !(target instanceof Element) ||
      isEditableTarget(target) ||
      target.closest(
        'button, a[href], area[href], summary, [role="button"], [role="link"], ' +
        '[role="slider"], [role^="menuitem"], [role="checkbox"], [role="radio"], ' +
        '[role="switch"], [role="tab"], [role="combobox"], [role="listbox"], ' +
        '[role="option"], [role="textbox"], [role="dialog"]'
      )
    ) {
      return null;
    }

    const player = target.closest("#movie_player, .html5-video-player");
    const videos = player
      ? player.querySelectorAll("video")
      : document.querySelectorAll("#movie_player video, .html5-video-player video");
    let displayedVideo = null;
    let fallbackVideo = null;
    let largestVisibleArea = 0;

    for (const video of videos) {
      if (document.fullscreenElement && !document.fullscreenElement.contains(video)) {
        continue;
      }

      const visibleArea = getVisibleArea(video);

      if (visibleArea > largestVisibleArea) {
        displayedVideo = video;
        largestVisibleArea = visibleArea;
      }

      // A watch-page video can keep playing while scrolled off screen. Still
      // block its spacebar hold, but never select a hidden/preloaded element.
      if (!fallbackVideo && (player || video.closest("#movie_player"))) {
        const bounds = video.getBoundingClientRect();
        const rendered =
          typeof video.checkVisibility !== "function" ||
          video.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true });

        if (rendered && bounds.width > 0 && bounds.height > 0) {
          fallbackVideo = video;
        }
      }
    }

    return displayedVideo || fallbackVideo;
  }

  function blockSpacebarHold(event) {
    if (!event.isTrusted || (event.code !== "Space" && event.key !== " ")) {
      return;
    }

    // Swallow the rest of a handled press even if focus or modifiers change.
    // YouTube must receive neither the initial keydown nor its keyup.
    if (spaceHeld) {
      if (event.type === "keyup") {
        spaceHeld = false;
      }

      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }

    if (
      event.type !== "keydown" ||
      event.repeat ||
      event.defaultPrevented ||
      event.isComposing ||
      event.ctrlKey ||
      event.altKey ||
      event.metaKey ||
      event.shiftKey
    ) {
      return;
    }

    const video = getSpacebarVideo(event.target);

    if (!video) {
      return;
    }

    spaceHeld = true;
    event.preventDefault();
    event.stopImmediatePropagation();

    // Keep the ordinary play/pause shortcut, once per press. Don't touch the
    // playback rate: deliberate 2x settings and Ctrl+Arrow adjustments remain.
    toggleVideoPlayback(video);
  }

  for (const type of ["pointerdown", "mousedown", "touchstart"]) {
    window.addEventListener(type, blockPointerHold, true);
  }

  window.addEventListener("click", handleVideoClick, true);

  for (const type of ["keydown", "keypress", "keyup"]) {
    window.addEventListener(type, blockSpacebarHold, true);
  }

  window.addEventListener("blur", () => {
    spaceHeld = false;
  });

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      spaceHeld = false;
    }
  });

  window.addEventListener(
    "keydown",
    (event) => {
      if (
        !event.isTrusted ||
        !event.ctrlKey ||
        event.altKey ||
        event.metaKey ||
        event.shiftKey ||
        (event.key !== "ArrowUp" && event.key !== "ArrowDown") ||
        isEditableTarget(event.target)
      ) {
        return;
      }

      const videos = document.querySelectorAll("video");

      if (videos.length === 0) {
        return;
      }

      const delta = event.key === "ArrowUp" ? 0.5 : -0.5;
      let displayedVideo = videos[0];
      let largestVisibleArea = 0;

      for (const video of videos) {
        const newRate = clampPlaybackRate(video.playbackRate + delta);
        video.playbackRate = newRate;

        // Prefer the visible player over hidden or preloaded video elements.
        const visibleArea = getVisibleArea(video);

        if (visibleArea > largestVisibleArea) {
          displayedVideo = video;
          largestVisibleArea = visibleArea;
        }
      }

      showSpeed(
        displayedVideo.playbackRate,
        largestVisibleArea > 0 ? displayedVideo : null
      );

      event.preventDefault();
      event.stopImmediatePropagation();
    },
    true
  );
})();
