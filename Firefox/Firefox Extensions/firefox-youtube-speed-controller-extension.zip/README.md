# YT Speed Controller 1.4.3

YouTube playback-speed controls for Firefox.

| Input | Action |
| --- | --- |
| Ctrl+Up | Increase speed by 0.5x, up to 16x |
| Ctrl+Down | Decrease speed by 0.5x, down to 0.5x |
| Tap or click the video | Toggle play/pause through YouTube's play button |
| Space | Toggle play/pause once per press |
| Hold Space or hold the mouse button on the video | No temporary 2x acceleration |

The speed overlay and existing Ctrl+Arrow controls are preserved. Deliberately
selecting 2x remains possible. The blocker doesn't lock, reset or continuously
monitor playback speed.

Video taps and primary clicks invoke YouTube's native play/pause button once.
If that button is absent, they toggle the visible video directly. Double-clicks,
right-clicks, timeline controls and player buttons retain their event handling.
Spacebar handling leaves editable fields,
interactive controls and modified shortcuts to the page. The watch-page
spacebar shortcut still works when the video has been scrolled out of view.

## Load or update

1. Extract this archive.
2. Open `about:debugging#/runtime/this-firefox`.
3. For an existing temporary installation, replace its extracted files and
   click **Reload**. Otherwise, click **Load Temporary Add-on** and select
   `manifest.json` from the extracted directory.
4. Reload existing YouTube tabs so they receive the updated script.

Temporary add-ons are removed when Firefox restarts. This archive contains
source files; permanent installation in standard Firefox requires a signed XPI.

## Implementation

The script runs at `document_start`, before YouTube installs its gesture
handlers. It intercepts press-start events only inside YouTube's video
container. It handles a plain spacebar press itself, including its repeat and
release events, because YouTube starts its acceleration timer on the initial
keydown. Playback toggles on the initial press, without changing the rate.

Version 1.4.3 fixes the tap-to-pause regression in 1.4.2. Blocking the initial
press can also prevent YouTube from preparing its own surface-click handler.
The extension therefore handles the later video click explicitly via the
native play button, consuming the surface click to prevent a second toggle.
Clicks on the play button itself aren't intercepted.

Players and videos are resolved when input occurs, so normal YouTube navigation
and player replacement don't require repeated initialization or polling.

The extension ID, icon, site access and permission declarations are unchanged.
It still runs only on `https://www.youtube.com/*` and doesn't request additional
permissions.

## Validation

The Firefox regression fixture includes a native surface-click handler that
depends on press bookkeeping. It reproduces 1.4.2's failed tap, then checks that
1.4.3 invokes the native play button exactly once per click. Other checks cover
both hold gestures, play/pause, fullscreen double-clicks, speed adjustments and
limits, typing, controls, player replacement, focus changes and offscreen video.
All 19 browser checks passed. Mozilla's add-on validator reported no errors,
warnings or notices.

Automated browser input can't reproduce the hardware and input stack of a
physical touchpad. Actual YouTube video streaming wasn't available in the
test environment; controlled playback checks use a test page.
