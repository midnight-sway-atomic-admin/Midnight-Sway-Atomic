const TOTAL_CELLS = 60;
const STORAGE_KEY = "speedDialData";
const URL_SCHEME_PATTERN = /^[a-z][a-z\d+.-]*:/i;

let dialData = [];
let currentIndex = null;

function normalizeUrl(value) {
  const rawUrl = String(value || "").trim();
  if (!rawUrl) return "";

  const candidate = URL_SCHEME_PATTERN.test(rawUrl) ? rawUrl : `https://${rawUrl}`;

  try {
    const url = new URL(candidate);
    return url.protocol === "http:" || url.protocol === "https:" ? url.href : "";
  } catch (_error) {
    return "";
  }
}

function normalizeCell(value) {
  const cell = value && typeof value === "object" ? value : {};

  return {
    text: String(cell.text || "").trim(),
    url: normalizeUrl(cell.url)
  };
}

function normalizeData(data) {
  const source = Array.isArray(data) ? data : [];
  return Array.from({ length: TOTAL_CELLS }, (_cell, index) => normalizeCell(source[index]));
}

function loadData() {
  try {
    dialData = normalizeData(JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"));
  } catch (_error) {
    dialData = normalizeData([]);
  }
}

function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(dialData));
}

function renderCells() {
  const grid = document.getElementById("grid");
  grid.replaceChildren();

  for (let i = 0; i < TOTAL_CELLS; i++) {
    const cellData = dialData[i];
    const cell = document.createElement(cellData.url ? "a" : "div");

    cell.className = "cell";
    cell.dataset.index = i;
    cell.textContent = cellData.text || (cellData.url ? cellData.url : "+");

    if (cellData.url) {
      cell.href = cellData.url;
    } else {
      cell.addEventListener("click", openEditor);
    }

    grid.appendChild(cell);
  }
}

function openEditor(event) {
  currentIndex = Number(event.currentTarget.dataset.index);
  const cellData = dialData[currentIndex];

  document.getElementById("cellText").value = cellData.text;
  document.getElementById("cellUrl").value = cellData.url;
  document.getElementById("modal").style.display = "flex";
}

function closeModal() {
  document.getElementById("modal").style.display = "none";
}

document.getElementById("saveBtn").addEventListener("click", function() {
  const text = document.getElementById("cellText").value.trim();
  const rawUrl = document.getElementById("cellUrl").value.trim();
  const url = normalizeUrl(rawUrl);

  if (rawUrl && !url) {
    alert("Only http:// and https:// URLs are supported.");
    return;
  }

  dialData[currentIndex] = { text, url };
  saveData();
  renderCells();
  closeModal();
});

document.getElementById("cancelBtn").addEventListener("click", closeModal);

document.getElementById("exportBtn").addEventListener("click", function() {
  const jsonData = JSON.stringify(dialData, null, 2);
  prompt("Copy your speed dial data:", jsonData);
});

document.getElementById("importBtn").addEventListener("click", function() {
  const importText = prompt("Paste your speed dial JSON data:");
  if (!importText) return;

  try {
    const imported = JSON.parse(importText);
    if (!Array.isArray(imported)) {
      alert("Invalid data format.");
      return;
    }

    dialData = normalizeData(imported);
    saveData();
    renderCells();
  } catch (_error) {
    alert("Error parsing JSON.");
  }
});

loadData();
renderCells();
