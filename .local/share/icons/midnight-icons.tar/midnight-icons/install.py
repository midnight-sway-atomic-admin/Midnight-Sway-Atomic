#!/usr/bin/env python3
"""Install Midnight for the current user; Python 3.9+ standard library only."""

import argparse
import configparser
import fcntl
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

THEME = "midnight-icons"
SOURCE = Path(__file__).resolve().parent


def fail(message):
    raise ValueError(message)


def xdg_path(variable, fallback):
    value = os.environ.get(variable, "")
    # XDG relative paths are invalid; use the specified default instead.
    return Path(value) if value and Path(value).is_absolute() else Path.home() / fallback


def inspect_package():
    index_path = SOURCE / "index.theme"
    if index_path.is_symlink():
        fail("index.theme must be a regular file")
    index = configparser.ConfigParser(interpolation=None, strict=True)
    index.optionxform = str
    index.read_string(index_path.read_text(encoding="utf-8"))
    header = index["Icon Theme"]
    if not header.get("Name") or not header.get("Comment"):
        fail("index.theme needs Name and Comment")
    directories = header.get("Directories", "").split(",")
    if len(set(directories)) != len(directories):
        fail("Repeated directory in index.theme")
    for directory in directories:
        path = Path(directory)
        if not directory or path.is_absolute() or ".." in path.parts or str(path) != directory:
            fail("Invalid icon directory: " + repr(directory))
        section = index[directory]
        if section.get("Type") != "Scalable":
            fail("Expected Type=Scalable for " + directory)
        if not 0 < section.getint("MinSize") <= section.getint("Size") <= section.getint("MaxSize"):
            fail("Invalid size range for " + directory)
        if not (SOURCE / directory).is_dir():
            fail("Missing icon directory: " + directory)

    files, aliases = [], []
    for path in sorted(SOURCE.rglob("*")):
        if path.is_symlink() and path.suffix != ".svg":
            fail("Only SVG file symlinks are supported: " + str(path))
        if path.suffix != ".svg":
            continue
        name = path.relative_to(SOURCE).as_posix()
        if path.parent.relative_to(SOURCE).as_posix() not in directories:
            fail("Unindexed icon: " + name)
        if path.is_symlink():
            target = os.readlink(path)
            if os.path.isabs(target):
                fail("Absolute icon symlink: " + name)
            base = path.resolve(strict=True)
            if not base.is_relative_to(SOURCE) or base.suffix != ".svg" or not base.is_file():
                fail("Symlink must target an SVG inside this theme: " + name)
            if (path.parent / target).is_symlink():
                fail("Symlinks must point directly to base SVGs: " + name)
            aliases.append(name)
        else:
            if ET.parse(path).getroot().tag != "{http://www.w3.org/2000/svg}svg":
                fail("Invalid SVG root: " + name)
            files.append(name)
    if not files or {str(Path(n).parent) for n in files + aliases} != set(directories):
        fail("index.theme and the icon directories don't agree")
    return files, aliases


def cache_theme(directory):
    executable = shutil.which("gtk-update-icon-cache") or shutil.which("gtk4-update-icon-cache")
    if not executable:
        print("Icon cache utility unavailable; installing without a cache.")
        return
    try:
        result = subprocess.run([executable, "--force", "--index-only", str(directory)],
                                capture_output=True, text=True, timeout=60)
        if result.returncode:
            raise RuntimeError(result.stderr.strip() or result.stdout.strip())
        check = subprocess.run([executable, "--validate", str(directory)],
                               capture_output=True, text=True, timeout=60)
        if check.returncode:
            raise RuntimeError("Generated icon cache failed validation")
        print("Icon cache built and validated.")
    except (OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
        (directory / "icon-theme.cache").unlink(missing_ok=True)
        print("Warning: installing without a cache: " + str(exc), file=sys.stderr)


def install_theme(icons_dir, files, aliases, build_cache):
    icons_dir = icons_dir.resolve()
    destination = icons_dir / THEME
    if destination == SOURCE or destination in SOURCE.parents or SOURCE in destination.parents:
        fail("The destination must be separate from the downloaded package")
    icons_dir.mkdir(parents=True, exist_ok=True)
    with (icons_dir / ("." + THEME + "-install.lock")).open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        with tempfile.TemporaryDirectory(prefix="." + THEME + "-stage-", dir=icons_dir) as temporary:
            stage = Path(temporary) / THEME
            stage.mkdir(mode=0o755)
            for name in files + ["index.theme"]:
                output = stage / name
                output.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(SOURCE / name, output)
                output.chmod(0o644)
            for name in aliases:
                output = stage / name
                output.parent.mkdir(parents=True, exist_ok=True)
                output.symlink_to(os.readlink(SOURCE / name))
            if build_cache:
                cache_theme(stage)
            # Replace only this theme. No backup directories are created.
            if destination.is_symlink():
                destination.unlink()
            elif destination.exists():
                if not destination.is_dir():
                    fail("Installation path is not a directory: " + str(destination))
                shutil.rmtree(destination)
            stage.rename(destination)
            os.utime(icons_dir, None)
    print("Installed: " + str(destination))
    print(f"{len(files)} base SVGs; {len(aliases)} relative symlinks.")
    return destination


def replace_setting(text):
    """Change only this GTK key, preserving unrelated settings and comments."""
    parser = configparser.ConfigParser(interpolation=None, strict=True)
    parser.optionxform = str
    if text.strip():
        parser.read_string(text)
    newline = "\r\n" if "\r\n" in text else "\n"
    lines = text.splitlines(keepends=True)
    result, in_settings, found_section, found_key = [], False, False, False
    for line in lines:
        section = re.match(r"^\s*\[([^]]+)\]", line)
        if section:
            if in_settings and not found_key:
                result.append("gtk-icon-theme-name=" + THEME + newline)
                found_key = True
            in_settings = section.group(1) == "Settings"
            found_section |= in_settings
        if in_settings and re.match(r"^\s*gtk-icon-theme-name\s*=", line):
            result.append("gtk-icon-theme-name=" + THEME + newline)
            found_key = True
        else:
            result.append(line)
    if result and not result[-1].endswith(("\n", "\r")):
        result[-1] += newline
    if not found_section:
        if result and result[-1].strip():
            result.append(newline)
        result.append("[Settings]" + newline)
    if not found_key:
        result.append("gtk-icon-theme-name=" + THEME + newline)
    return "".join(result)


def activate():
    config_home = xdg_path("XDG_CONFIG_HOME", ".config")
    planned = []
    for version in ("gtk-3.0", "gtk-4.0"):
        path = config_home / version / "settings.ini"
        if path.is_symlink():
            # Follow a user's config symlink, rather than destroying it.
            path = path.resolve(strict=True)
        old = path.read_bytes() if path.exists() else b""
        new = replace_setting(old.decode("utf-8")).encode("utf-8")
        if old != new:
            planned.append((path, new))
    for path, content in planned:
        path.parent.mkdir(parents=True, exist_ok=True)
        mode = 0o644
        if path.exists():
            mode = path.stat().st_mode & 0o777
        fd, temporary = tempfile.mkstemp(prefix=".midnight-settings-", dir=path.parent)
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(content)
            os.chmod(temporary, mode)
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        print("Updated: " + str(path))
    # Wayland GTK sessions may get the setting from GSettings/portals.
    executable = shutil.which("gsettings")
    schema = "org.gnome.desktop.interface"
    if executable:
        try:
            result = subprocess.run([executable, "set", schema, "icon-theme", THEME],
                                    capture_output=True, text=True, timeout=15)
            if result.returncode or result.stderr.strip():
                print("Warning: GSettings reported: " + (result.stderr.strip() or result.stdout.strip()),
                      file=sys.stderr)
            else:
                print("GSettings icon theme set to " + THEME + ".")
        except (OSError, subprocess.TimeoutExpired) as exc:
            print("Warning: couldn't update GSettings: " + str(exc), file=sys.stderr)
    print("GTK settings select " + THEME + ". Restart apps or log out and back in.")
    print("If you use a session settings manager or an app-specific theme setting, select " + THEME + " there too.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="validate the download without installing")
    parser.add_argument("--activate", action="store_true", help="also select this theme in GTK 3/4 settings and GSettings")
    parser.add_argument("--icons-dir", type=Path, help="custom icons parent directory (default: $XDG_DATA_HOME/icons)")
    parser.add_argument("--no-cache", action="store_true", help="skip the optional GTK icon cache")
    args = parser.parse_args()
    if args.check and args.activate:
        parser.error("--check and --activate cannot be combined")
    if args.activate and args.icons_dir is not None:
        parser.error("--activate requires the standard user installation directory")
    try:
        files, aliases = inspect_package()
        if args.check:
            print(f"Package valid: {len(files)} base SVGs and {len(aliases)} aliases.")
            return 0
        if os.environ.get("SUDO_USER"):
            fail("Run without sudo; this installer installs for the current user")
        icons_dir = args.icons_dir.expanduser().absolute() if args.icons_dir else xdg_path("XDG_DATA_HOME", ".local/share") / "icons"
        install_theme(icons_dir, files, aliases, not args.no_cache)
        if args.activate:
            try:
                activate()
            except (OSError, ValueError, configparser.Error) as exc:
                print("Theme installed, but activation wasn't completed: " + str(exc), file=sys.stderr)
                return 1
        else:
            print("To select the theme as well, run this installer with --activate.")
        return 0
    except (OSError, ValueError, KeyError, TypeError, RuntimeError, ET.ParseError, configparser.Error) as exc:
        print("Error: " + str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
