# Midnight icons

Custom SVG icons for Fedora Sway Atomic. Theme name: `midnight-icons`.

## Install

Extract the complete TAR archive, open a terminal inside `midnight-icons`, and run:

```sh
python3 install.py --activate
```

Run as your normal user, without `sudo`. Requires Python 3.9 or newer;
no additional Python packages or network access are needed.

The installer uses `~/.local/share/icons/midnight-icons`, or
`$XDG_DATA_HOME/icons/midnight-icons` if `XDG_DATA_HOME` is an absolute path.
Rerunning it replaces this theme and removes stale files without creating backups.
Other installed themes are left intact. A GTK icon cache is built when the utility
is available.

`--activate` selects the theme in GTK 3/4 settings and attempts to set GSettings.
Unrelated settings, comments and configuration symlinks are preserved. Restart
applications afterward; session or application-specific settings may also need
updating.

Use `python3 install.py` to install without selecting the theme.
Use `python3 install.py --check` to validate the extracted package.
Optional: `--icons-dir /absolute/path/to/icons` chooses a different parent folder;
`--no-cache` skips the cache. `--activate` requires the default installation location.

To uninstall, select another theme and remove the installed `midnight-icons` folder.

## Files and symlinks

1,218 SVG paths: 1,068 regular files and 150 symlinks.
`SYMLINKS.tsv` lists every link and its target. All links are relative and point
directly to regular SVG files inside the theme. No manifest is required.

Keep the complete theme folder together when moving it. Extract with a tool that
preserves Unix symlinks, such as `tar -xf archive.tar`. To recreate an archive,
use `tar -cf midnight-icons.tar midnight-icons/` without `--dereference` or `-h`.
The installed theme remains usable after the downloaded folder is moved or deleted.

`start-here.svg` points to `fedora-logo-icon.svg`.
`web-browser.svg` shares the existing neutral globe artwork. The four symbolic
application icons are in `symbolic/apps`. Standard `audio-input-microphone.svg` and
`x-office-address-book.svg` aliases preserve the original filenames too.

All 23 icon directories are indexed, including this theme's nested `hicolor`
folders. Missing icons fall back to Adwaita and hicolor. The networking version of
`nm-device-wireless.svg` is preferred at 8–48 pixels; its application version
serves larger requests.

`extras/alternative-8a97bf-wifi-icons.zip` is retained unchanged and isn't installed
automatically. To use its 56 optional Wi-Fi icons, extract the ZIP and copy its
SVGs over the matching files in `scalable/networking` before installing.

GTK may recolour symbolic icons according to application styling. Embedded images
and icons loaded by absolute path are outside theme lookup.

The theme covers all 1,196 distinct non-cursor icon names in the supplied
Fedora system-icon snapshot, counting each name once across sizes and formats.
