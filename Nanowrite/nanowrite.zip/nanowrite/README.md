# Nanowrite

A separate, modified GNU nano 9.2 build for x86_64 Linux, prepared on 20 October 2026.
Your system nano and its configuration aren't changed.

While writing, the interface shows only the document's filename and live word
count, horizontally centered together as one group at the top. The count is
immediately to the right of the filename, separated by a middle dot with a space
on each side: `document.txt · 123 words`.
Untitled documents show `Untitled`. Long names are shortened to fit; in extremely
narrow windows, the filename takes priority over the counter.
The rest of the window uses black text on an opaque, slightly off-white background
(`#F5F3EE`). Lines wrap at spaces without inserting line breaks into the file.
There are no shortcut rows, version label, modification label, line numbers, or
routine read/write notices. Save/open prompts and errors still appear when needed.
The status row at the bottom is otherwise blank.
Two blank screen rows separate the document from the bottom save/status line.
The document scrolls within the shorter writing area; this space stays blank
while a save prompt is open. Extremely short windows reduce the gap to keep at
least one writing row available.

The launcher uses a non-blinking black beam cursor, 1 point thick.

The writing area is a horizontally centered column up to 76 characters wide.
Its text stays left-aligned, with a ragged right edge. Four blank text rows
separate it from the header, giving the page a modest top margin. These
are display margins: they never become spaces or line breaks in your document.
On short windows the top gap shrinks to leave at least eight writing rows when
the window is tall enough. The column adapts to narrower windows too.

The physical size of the top gap depends on font size and display scaling.
To adjust it, edit these settings near the top of the installed launcher:

```bash
page_width=76
top_blank_rows=4
```

The launcher is `$HOME/.config/rofi/scripts/nanowrite.sh`.

The word count includes unsaved text and updates after each input batch, including
typing, deletion, undo/redo, and paste. It counts the whole document, following
nano's normal word-character rules, including punctuation. It doesn't count only
the visible portion or read only the saved file.

## Install

Extract this ZIP. From the extracted `nanowrite` directory, run:

```bash
bash install.sh
```

No sudo, package layering, or compiler is needed for the included build. It uses
the standard x86_64 Linux dynamic loader, glibc 2.38 or later, and ncursesw/tinfo ABI 6. It was built
and tested on Ubuntu 24.04; a live Fedora Sway session was not available for testing.

The installer writes only these two files:

```text
${XDG_DATA_HOME:-$HOME/.local/share}/nanowrite/nanowrite
$HOME/.config/rofi/scripts/nanowrite.sh
```

It replaces earlier copies at those two paths. If you edited the earlier writing
launcher yourself, retain those edits before installing this version.

Change the menu's displayed entry to `Nanowrite` and use this matching case:

```bash
  "Nanowrite")
    bash "$HOME/.config/rofi/scripts/nanowrite.sh" >> "$logfile" 2>&1 &
    ;;
```

The included `rofi-apps` has both changes applied to the menu you supplied.
You can use that file as your menu, or apply the two changes to your current
menu if you've since edited it. The installer doesn't replace your menu.

When upgrading from the earlier name, run this installer and update rofi to the
new launcher path above. The old `nano-writing.sh` launcher and
`${XDG_DATA_HOME:-$HOME/.local/share}/nano-writing` installation are no longer
needed; the installer leaves them in place.

Mouse support is enabled by default. Left-click within the text to position the
cursor. Hold Shift while dragging to select text through the terminal; Alt+M
toggles nano's mouse support for the current session.
Shift-drag selections use dark blue text (`#315B8A`) on the page's off-white
background. Blank margin cells keep the page colour instead of forming a black
block. This changes only the selection's appearance; the selected cells and
terminal clipboard behaviour stay the same. Adjust `selection_foreground` near
the top of the launcher to use a different selection text colour.

Ctrl+O opens the save prompt; Ctrl+X exits. Add filenames after the launcher
command to open them directly. The new profile doesn't import your usual nanorc.

## Source and rebuilding

This is a local modification, not an official nano release. The original copyright
notices and GPLv3-or-later terms are retained; see `COPYING` and the source archive.
`source/nano-9.2-nanowrite.tar.xz` includes the complete modified source and build
instructions. `source/nanowrite.patch` records the changes to nano's source files.

On a system or build container with GCC, make, and ncurses development headers:

```bash
tar --no-same-owner -xf source/nano-9.2-nanowrite.tar.xz
cd nano-9.2
./configure --disable-nls --disable-libmagic
make -j4
```

The resulting editor is `src/nano`. It can replace `bin/nanowrite` before
running the installer. Updated nano releases require rebuilding and reapplying
or adapting this patch; system updates won't update this separate executable.

## Validation

Final audit: 20 October 2026. Corrected filename-completion lists to fit the
writing column, help layout after toggling shortcut rows, scrollbar click
coordinates, a crash on very narrow windows with line numbers enabled, and
progress text left behind after a successful save. Simplified redundant header
and browser code. Header updates now join nano's normal screen refresh.

Passed behavioral checks through real pseudo-terminals in both the regular build
and a separate AddressSanitizer/UndefinedBehaviorSanitizer build: editing,
undo/redo, cut/paste, Unicode and combining characters, word counts, centered
headers, wrapping, mouse positioning, scrolling, bottom spacing, help/browser
transitions, filename completion, multiple buffers, save errors and recovery,
and a 100,000-word document. Tested 63 terminal-size combinations, including
one-column and one-row windows, plus optional line numbers and scrollbar use.
A deterministic 220-action editing sequence saved exactly the same bytes as
unmodified GNU nano 9.2. No sanitizer errors occurred in these tests; leak
detection was disabled because it is unsupported in the test environment.

Bash syntax and ShellCheck checks passed. Isolated installation/launcher tests
covered repeated installation, paths with spaces, literal filename arguments,
configuration isolation, temporary-file permissions and cleanup, failure exit
status, and modern/legacy foot option branches. The foot branches were tested
with a test double; live foot rendering and compositor behavior require a Sway
session. The ZIP, executable, patch, and included source were checked for
consistency. These checks found no remaining failures in the tested cases;
they do not establish that all possible inputs and environments are bug-free.
