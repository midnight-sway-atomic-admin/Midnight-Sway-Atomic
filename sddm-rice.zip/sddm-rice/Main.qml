import QtQuick 2.15
import SddmComponents 2.0

Rectangle {
    id: root

    width: 1920
    height: 1080
    color: "#000000"

    property color accent: "#8a97bf"
    property color accentLight: "#c7cde0"
    property color accentMid: "#59617d"
    property color accentDark: "#252a37"
    property color fieldBackground: "#08090c"

    property int sessionIndex: sessionModel.lastIndex >= 0 ? sessionModel.lastIndex : 0
    property string statusText: ""
    property bool loginBusy: false

    function attemptLogin() {
        if (loginBusy || username.text.length === 0)
            return

        statusText = ""
        loginBusy = true
        sddm.login(username.text, password.text, sessionIndex)
    }

    Connections {
        target: sddm

        function onLoginFailed() {
            root.loginBusy = false
            root.statusText = "authentication failed"
            password.text = ""
            password.forceActiveFocus()
        }

        function onLoginSucceeded() {
            root.loginBusy = true
            root.statusText = ""
        }

        function onInformationMessage(message) {
            root.loginBusy = false
            root.statusText = message
        }
    }

    Column {
        id: loginPanel

        width: Math.min(300, root.width - 64)
        spacing: 11
        anchors.centerIn: parent

        Text {
            text: "user"
            color: root.accentMid
            font.pixelSize: 10
            font.letterSpacing: 1.2
        }

        Rectangle {
            width: parent.width
            height: 42
            radius: 3
            color: root.fieldBackground
            border.width: 1
            border.color: root.accentDark

            TextInput {
                id: username

                anchors.fill: parent
                anchors.leftMargin: 13
                anchors.rightMargin: 13
                verticalAlignment: TextInput.AlignVCenter

                text: userModel.lastUser
                color: root.accentLight
                selectionColor: root.accent
                selectedTextColor: "#000000"
                font.pixelSize: 14
                clip: true
                focus: userModel.lastUser === ""

                KeyNavigation.tab: password

                Keys.onPressed: function(event) {
                    if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                        password.forceActiveFocus()
                        event.accepted = true
                    }
                }
            }
        }

        Text {
            text: "password"
            color: root.accentMid
            font.pixelSize: 10
            font.letterSpacing: 1.2
        }

        Rectangle {
            width: parent.width
            height: 42
            radius: 3
            color: root.fieldBackground
            border.width: 1
            border.color: root.accentDark

            TextInput {
                id: password

                anchors.fill: parent
                anchors.leftMargin: 13
                anchors.rightMargin: 13
                verticalAlignment: TextInput.AlignVCenter

                color: root.accentLight
                selectionColor: root.accent
                selectedTextColor: "#000000"
                font.pixelSize: 14
                echoMode: TextInput.Password
                clip: true
                focus: userModel.lastUser !== ""

                KeyNavigation.tab: username
                KeyNavigation.backtab: username

                Keys.onPressed: function(event) {
                    if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                        root.attemptLogin()
                        event.accepted = true
                    } else if (event.key === Qt.Key_Escape) {
                        password.text = ""
                        event.accepted = true
                    }
                }
            }
        }

        Item {
            width: parent.width
            height: keyboard.capsLock ? 14 : 0
            visible: keyboard.capsLock

            Text {
                anchors.right: parent.right
                text: "caps lock"
                color: root.accentMid
                font.pixelSize: 9
                font.letterSpacing: 0.7
            }
        }

        Item {
            width: parent.width
            height: 17

            Text {
                anchors.centerIn: parent
                width: parent.width
                horizontalAlignment: Text.AlignHCenter
                elide: Text.ElideRight

                text: root.statusText
                color: root.accent
                font.pixelSize: 10
            }
        }
    }

    Component.onCompleted: {
        if (userModel.lastUser === "")
            username.forceActiveFocus()
        else
            password.forceActiveFocus()
    }
}
